import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import routing

from resources.lib import tamilgun
from resources.lib import movierulz
from resources.lib import tamilyogi
from resources.lib import tamilbulb
from resources.lib import arivumani
from resources.lib import gomovies
from resources.lib import einthusan
from resources.lib import tamilyogi2
from resources.lib import kuttymovies
from resources.lib import moviebox
from resources.lib import tamilbliss
from resources.lib import tamildhool
from resources.lib import mewatch
from resources.lib import resolvers

plugin = routing.Plugin()

import os
import xbmcaddon
addon = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(addon.getAddonInfo('path'))
IMG_DIR = os.path.join(ADDON_PATH, 'resources', 'images')
FANART_PATH = os.path.join(ADDON_PATH, 'fanart.png')

xbmc.log(f"SivaDelight Addon version: {addon.getAddonInfo('version')}", xbmc.LOGINFO)

@plugin.route('/')
def index():
    # Trigger repository update check on launch to ensure auto-updates
    xbmc.executebuiltin('UpdateAddonRepos')
    
    # Force a local addon refresh and then check for repo updates
    xbmc.executebuiltin('UpdateLocalAddons')
    xbmc.executebuiltin('UpdateAddonRepos')
    
    tg_item = xbmcgui.ListItem('[B]TamilGun : [COLOR yellow]Tamil Movies[/COLOR][/B]')
    tg_item.setArt({'icon': os.path.join(IMG_DIR, 'TamilGun.png'), 'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamilgun_index), tg_item, isFolder=True)
    
    mr_item = xbmcgui.ListItem('[B]MovieRulZ : [COLOR yellow]Movies[/COLOR][/B]')
    mr_item.setArt({'icon': os.path.join(IMG_DIR, 'MovieRulz.png'), 'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(movierulz_index), mr_item, isFolder=True)
    
    ty_item = xbmcgui.ListItem('[B]TamilYogi : [COLOR yellow]Tamil Movies[/COLOR][/B]')
    ty_item.setArt({'icon': os.path.join(IMG_DIR, 'TamilYogi.png'), 'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamilyogi_index), ty_item, isFolder=True)
    
    ty2_item = xbmcgui.ListItem('[B]TamilYogi 2 : [COLOR yellow]Tamil Movies[/COLOR][/B]')
    ty2_item.setArt({'icon': os.path.join(IMG_DIR, 'TamilYogi2.png'), 'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamilyogi2_index), ty2_item, isFolder=True)
    
    tb_item = xbmcgui.ListItem('[B]TamilBulB : [COLOR yellow]Tamil Movies[/COLOR][/B]')
    tb_item.setArt({'icon': os.path.join(IMG_DIR, 'TamilBulb.png'), 'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamilbulb_index), tb_item, isFolder=True)
    
    ariv_item = xbmcgui.ListItem('[B]ArivuManI : [COLOR yellow]Tamil Catch-up Serial[/COLOR][/B]')
    ariv_item.setArt({'icon': os.path.join(IMG_DIR, 'ArivuMani.png'), 'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(arivumani_index), ariv_item, isFolder=True)
    
    go_item = xbmcgui.ListItem('[B]Go MovieS : [COLOR yellow]Various[/COLOR][/B]')
    go_item.setArt({'icon': os.path.join(IMG_DIR, 'GoMovie.png'), 'thumb': os.path.join(IMG_DIR, 'GoMovie.png'), 'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(gomovies_index), go_item, isFolder=True)
    
    ein_item = xbmcgui.ListItem('[B]EinthusaN : [COLOR yellow]Various (Blocked)[/COLOR][/B]')
    ein_item.setArt({'icon': os.path.join(IMG_DIR, 'Einthusan.png'), 'thumb': os.path.join(IMG_DIR, 'Einthusan.png'), 'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(einthusan_index), ein_item, isFolder=True)
    
    km_item = xbmcgui.ListItem('[B]KuttyMovieS : [COLOR yellow]Tamil Movies[/COLOR][/B]')
    km_item.setArt({'icon': os.path.join(IMG_DIR, 'KuttyMovies.png'), 'thumb': os.path.join(IMG_DIR, 'KuttyMovies.png'), 'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(kuttymovies_index), km_item, isFolder=True)
    
    mb_item = xbmcgui.ListItem('[B]MovieBoX : [COLOR yellow]Various[/COLOR][/B]')
    mb_item.setArt({'icon': os.path.join(IMG_DIR, 'MovieBox.png'), 'thumb': os.path.join(IMG_DIR, 'MovieBox.png'), 'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(moviebox_index), mb_item, isFolder=True)
    
    tbliss_item = xbmcgui.ListItem('[B]TamilBlisS : [COLOR yellow]Tamil Catch-up Serial[/COLOR][/B]')
    tbliss_item.setArt({'icon': os.path.join(IMG_DIR, 'TamilBliss.png'), 'thumb': os.path.join(IMG_DIR, 'TamilBliss.png'), 'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamilbliss_index), tbliss_item, isFolder=True)
    
    td_item = xbmcgui.ListItem('[B]TamilDhool : [COLOR yellow]Tamil Catch-up Serial[/COLOR][/B]')
    td_item.setArt({'icon': os.path.join(IMG_DIR, 'SunTv.jpg'), 'thumb': os.path.join(IMG_DIR, 'SunTv.jpg'), 'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamildhool_index), td_item, isFolder=True)
    
    mw_item = xbmcgui.ListItem('[B]meWATCH Tamil : [COLOR yellow]Dramas & Live TV[/COLOR][/B]')
    mw_item.setArt({'icon': os.path.join(IMG_DIR, 'mewatch.png'), 'thumb': os.path.join(IMG_DIR, 'mewatch.png'), 'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(mewatch_index), mw_item, isFolder=True)
    
    support_item = xbmcgui.ListItem('[COLOR gold][B]Support Development[/B][/COLOR]')
    support_item.setArt({'icon': os.path.join(IMG_DIR, 'support.png'), 'thumb': os.path.join(IMG_DIR, 'support.png'), 'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(support_index), support_item, isFolder=True)
    
    clear_item = xbmcgui.ListItem('[COLOR yellow][B]Clear Cache[/B][/COLOR]')
    clear_item.setArt({'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(clear_cache), clear_item, isFolder=False)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/support')
def support_index():
    donate_dir = os.path.join(IMG_DIR, 'donations')
    
    # Ko-fi Item
    kofi_item = xbmcgui.ListItem('[B]Donate via Ko-fi (International)[/B]')
    kofi_item.setInfo('video', {'plot': 'Click to view the Ko-fi donation link and QR code.'})
    kofi_item.setArt({'icon': os.path.join(donate_dir, 'kofi_qr.png'), 'thumb': os.path.join(donate_dir, 'kofi_qr.png'), 'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(show_qr, title='Ko-fi Donation', image='kofi_qr.png'), kofi_item, isFolder=False)
    
    # TNG Item
    tng_item = xbmcgui.ListItem('[B]Scan TNG / DuitNow QR (Malaysia & India)[/B]')
    tng_item.setInfo('video', {'plot': 'Click to open the TNG / DuitNow QR code in full screen for easy scanning.'})
    tng_item.setArt({'icon': os.path.join(donate_dir, 'tng_qr.jpg'), 'thumb': os.path.join(donate_dir, 'tng_qr.jpg'), 'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(show_qr, title='TNG QR Code', image='tng_qr.jpg'), tng_item, isFolder=False)
    
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/show_qr/<title>/<image>')
def show_qr(title, image):
    qr_path = os.path.join(IMG_DIR, 'donations', image)
    # Open the image in Kodi's built-in picture viewer
    xbmc.executebuiltin(f'ShowPicture("{qr_path}")')
    
    # Also show a small notification/dialog with a thank you message
    xbmcgui.Dialog().notification('SivaDelight Support', f'Thank you for supporting {title}!', xbmcgui.NOTIFICATION_INFO, 5000)

# --- TAMILGUN ---
@plugin.route('/tamilgun')
def tamilgun_index():
    menus = tamilgun.get_menus()
    for m in menus:
        item = xbmcgui.ListItem(m['title'])
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamilgun_movies, url=m['url']), item, isFolder=True)
    
    # Place Search at the bottom
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(search, provider='tamilgun'), xbmcgui.ListItem('[COLOR yellow][B]Search...[/B][/COLOR]'), isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/tamilgun/movies')
def tamilgun_movies(url=None):
    if not url:
        url = plugin.args.get('url')[0]
    movies, next_page = tamilgun.get_movies(url)
    for m in movies:
        item = xbmcgui.ListItem(m['title'])
        art = {'fanart': FANART_PATH}
        if m.get('image'):
            art.update({'thumb': m['image'], 'icon': m['image']})
        item.setArt(art)
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamilgun_players, url=m['url'], title=m['title']), item, isFolder=True)
    if next_page:
        item = xbmcgui.ListItem("Next Page >>")
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamilgun_movies, url=next_page), item, isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/tamilgun/players')
def tamilgun_players():
    url = plugin.args.get('url')[0]
    title = plugin.args.get('title')[0]
    players = tamilgun.get_players(url)
    for p in players:
        item = xbmcgui.ListItem(f"{title} - {p['title']}")
        item.setArt({'fanart': FANART_PATH})
        item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(play_video, url=p['url'], referer=url), item, isFolder=False)
    xbmcplugin.endOfDirectory(plugin.handle)

# --- MOVIERULZ ---
@plugin.route('/movierulz')
def movierulz_index():
    menus = movierulz.get_menus()
    for m in menus:
        item = xbmcgui.ListItem(m['title'])
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(movierulz_movies, url=m['url']), item, isFolder=True)
    
    # Place Search at the bottom
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(search, provider='movierulz'), xbmcgui.ListItem('[COLOR yellow][B]Search...[/B][/COLOR]'), isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/movierulz/movies')
def movierulz_movies(url=None):
    if not url:
        url = plugin.args.get('url')[0]
    movies, next_page = movierulz.get_movies(url)
    for m in movies:
        item = xbmcgui.ListItem(m['title'])
        art = {'fanart': FANART_PATH}
        if m.get('image'):
            art.update({'thumb': m['image'], 'icon': m['image']})
        item.setArt(art)
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(movierulz_players, url=m['url'], title=m['title']), item, isFolder=True)
    if next_page:
        item = xbmcgui.ListItem("Next Page >>")
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(movierulz_movies, url=next_page), item, isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/movierulz/players')
def movierulz_players():
    url = plugin.args.get('url')[0]
    title = plugin.args.get('title')[0]
    players = movierulz.get_players(url)
    for p in players:
        item = xbmcgui.ListItem(f"{title} - {p['title']}")
        item.setArt({'fanart': FANART_PATH})
        item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(play_video, url=p['url'], referer=url), item, isFolder=False)
    xbmcplugin.endOfDirectory(plugin.handle)

# --- TAMILYOGI ---
@plugin.route('/tamilyogi')
def tamilyogi_index():
    menus = tamilyogi.get_menus()
    for m in menus:
        item = xbmcgui.ListItem(m['title'])
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamilyogi_movies, url=m['url']), item, isFolder=True)
    
    # Place Search at the bottom
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(search, provider='tamilyogi'), xbmcgui.ListItem('[COLOR yellow][B]Search...[/B][/COLOR]'), isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/tamilyogi/movies')
def tamilyogi_movies(url=None):
    if not url:
        url = plugin.args.get('url')[0]
    movies, next_page = tamilyogi.get_movies(url)
    for m in movies:
        item = xbmcgui.ListItem(m['title'])
        art = {'fanart': FANART_PATH}
        if m.get('image'):
            art.update({'thumb': m['image'], 'icon': m['image']})
        item.setArt(art)
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamilyogi_players, url=m['url'], title=m['title']), item, isFolder=True)
    if next_page:
        item = xbmcgui.ListItem("Next Page >>")
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamilyogi_movies, url=next_page), item, isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/tamilyogi/players')
def tamilyogi_players():
    url = plugin.args.get('url')[0]
    title = plugin.args.get('title')[0]
    players = tamilyogi.get_players(url)
    for p in players:
        item = xbmcgui.ListItem(f"{title} - {p['title']}")
        item.setArt({'fanart': FANART_PATH})
        item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(play_video, url=p['url'], referer=url), item, isFolder=False)
    xbmcplugin.endOfDirectory(plugin.handle)

# --- TAMILBULB ---
@plugin.route('/tamilbulb')
def tamilbulb_index():
    menus = tamilbulb.get_menus()
    for m in menus:
        item = xbmcgui.ListItem(m['title'])
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamilbulb_movies, url=m['url']), item, isFolder=True)
    
    # Place Search at the bottom
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(search, provider='tamilbulb'), xbmcgui.ListItem('[COLOR yellow][B]Search...[/B][/COLOR]'), isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/tamilbulb/movies')
def tamilbulb_movies(url=None):
    if not url:
        url = plugin.args.get('url')[0]
    movies, next_page = tamilbulb.get_movies(url)
    for m in movies:
        item = xbmcgui.ListItem(m['title'])
        art = {'fanart': FANART_PATH}
        if m.get('image'):
            art.update({'thumb': m['image'], 'icon': m['image']})
        item.setArt(art)
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamilbulb_players, url=m['url'], title=m['title']), item, isFolder=True)
    if next_page:
        item = xbmcgui.ListItem("Next Page >>")
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamilbulb_movies, url=next_page), item, isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/tamilbulb/players')
def tamilbulb_players():
    url = plugin.args.get('url')[0]
    title = plugin.args.get('title')[0]
    players = tamilbulb.get_players(url)
    for p in players:
        item = xbmcgui.ListItem(f"{title} - {p['title']}")
        item.setArt({'fanart': FANART_PATH})
        item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(play_video, url=p['url'], referer=url), item, isFolder=False)
    xbmcplugin.endOfDirectory(plugin.handle)

# --- ARIVUMANI ---
@plugin.route('/arivumani')
def arivumani_index():
    channels = arivumani.get_channels()
    for c in channels:
        item = xbmcgui.ListItem(c['title'])
        art = {'fanart': FANART_PATH}
        if c.get('icon'):
            art.update({'icon': os.path.join(IMG_DIR, c['icon']), 'thumb': os.path.join(IMG_DIR, c['icon'])})
        item.setArt(art)
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(arivumani_episodes, url=c['url']), item, isFolder=True)
    
    # Place Search at the bottom
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(search, provider='arivumani'), xbmcgui.ListItem('[COLOR yellow][B]Search...[/B][/COLOR]'), isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/arivumani/episodes')
def arivumani_episodes(url=None):
    if not url:
        url = plugin.args.get('url')[0]
    episodes, next_page = arivumani.get_episodes(url)
    for e in episodes:
        item = xbmcgui.ListItem(e['title'])
        art = {'fanart': FANART_PATH}
        if e.get('image'):
            art.update({'thumb': e['image'], 'icon': e['image']})
        item.setArt(art)
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(arivumani_players, url=e['url'], title=e['title']), item, isFolder=True)
    if next_page:
        item = xbmcgui.ListItem("Next Page >>")
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(arivumani_episodes, url=next_page), item, isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/arivumani/players')
def arivumani_players():
    url = plugin.args.get('url')[0]
    title = plugin.args.get('title')[0]
    players = arivumani.get_videos(url)
    
    if not players:
        xbmcgui.Dialog().ok('SivaDelight', 'No standard players found on this page. Wait for link extraction updates or try another.')

    for p in players:
        item = xbmcgui.ListItem(f"{title} - {p['title']}")
        item.setArt({'fanart': FANART_PATH})
        item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(play_video, url=p['url'], referer=url), item, isFolder=False)
    xbmcplugin.endOfDirectory(plugin.handle)

# --- GO MOVIES ---
@plugin.route('/gomovies')
def gomovies_index():
    menus = gomovies.get_menus()
    for m in menus:
        item = xbmcgui.ListItem(m['title'])
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(gomovies_movies, url=m['url']), item, isFolder=True)
    
    # Place Search at the bottom
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(search, provider='gomovies'), xbmcgui.ListItem('[COLOR yellow][B]Search...[/B][/COLOR]'), isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/gomovies/movies')
def gomovies_movies(url=None):
    if not url:
        url = plugin.args.get('url')[0]
    movies, next_page = gomovies.get_movies(url)
    for m in movies:
        item = xbmcgui.ListItem(m['title'])
        art = {'fanart': FANART_PATH}
        if m.get('image'):
            art.update({'thumb': m['image'], 'icon': m['image']})
        item.setArt(art)
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(gomovies_players, url=m['url'], title=m['title']), item, isFolder=True)
    if next_page:
        item = xbmcgui.ListItem("Next Page >>")
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(gomovies_movies, url=next_page), item, isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/gomovies/players')
def gomovies_players():
    url = plugin.args.get('url')[0]
    title = plugin.args.get('title')[0]
    players = gomovies.get_players(url)
    for p in players:
        item = xbmcgui.ListItem(f"{title} - {p['title']}")
        item.setArt({'fanart': FANART_PATH})
        item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(play_video, url=p['url'], referer=url), item, isFolder=False)
    xbmcplugin.endOfDirectory(plugin.handle)

# --- TAMILYOGI 2 ---
@plugin.route('/tamilyogi2')
def tamilyogi2_index():
    menus = tamilyogi2.get_menus()
    for m in menus:
        item = xbmcgui.ListItem(m['title'])
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamilyogi2_movies, url=m['url']), item, isFolder=True)
    
    # Place Search at the bottom
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(search, provider='tamilyogi2'), xbmcgui.ListItem('[COLOR yellow][B]Search...[/B][/COLOR]'), isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/tamilyogi2/movies')
def tamilyogi2_movies(url=None):
    if not url:
        url = plugin.args.get('url')[0]
    movies, next_page = tamilyogi2.get_movies(url)
    for m in movies:
        item = xbmcgui.ListItem(m['title'])
        art = {'fanart': FANART_PATH}
        if m.get('image'):
            art.update({'thumb': m['image'], 'icon': m['image']})
        item.setArt(art)
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamilyogi2_players, url=m['url'], title=m['title']), item, isFolder=True)
    if next_page:
        item = xbmcgui.ListItem("Next Page >>")
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamilyogi2_movies, url=next_page), item, isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/tamilyogi2/players')
def tamilyogi2_players():
    url = plugin.args.get('url')[0]
    title = plugin.args.get('title')[0]
    players = tamilyogi2.get_players(url)
    for p in players:
        item = xbmcgui.ListItem(f"{title} - {p['title']}")
        item.setArt({'fanart': FANART_PATH})
        item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(play_video, url=p['url'], referer=url), item, isFolder=False)
    xbmcplugin.endOfDirectory(plugin.handle)

# --- EINTHUSAN ---
@plugin.route('/einthusan')
def einthusan_index():
    menus = einthusan.get_menus()
    for m in menus:
        item = xbmcgui.ListItem(m['title'])
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(einthusan_categories, url=m['url']), item, isFolder=True)
    
    # Place Search at the bottom
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(search, provider='einthusan'), xbmcgui.ListItem('[COLOR yellow][B]Search...[/B][/COLOR]'), isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/einthusan/categories')
def einthusan_categories():
    url = plugin.args.get('url')[0]
    cats = einthusan.get_categories(url)
    for c in cats:
        item = xbmcgui.ListItem(c['title'])
        art = {'fanart': FANART_PATH}
        if c.get('image'):
            art.update({'thumb': c['image'], 'icon': c['image']})
        item.setArt(art)
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(einthusan_movies, url=c['url']), item, isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/einthusan/movies')
def einthusan_movies(url=None):
    if not url:
        url = plugin.args.get('url')[0]
    movies, next_page = einthusan.get_items(url)
    for m in movies:
        item = xbmcgui.ListItem(m['title'])
        art = {'fanart': FANART_PATH}
        if m.get('image'):
            art.update({'thumb': m['image'], 'icon': m['image']})
        item.setArt(art)
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(einthusan_play, url=m['url'], title=m['title']), item, isFolder=False)
    if next_page:
        item = xbmcgui.ListItem("Next Page >>")
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(einthusan_movies, url=next_page), item, isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/einthusan/play')
def einthusan_play():
    url = plugin.args.get('url')[0]
    stream_url = einthusan.get_video(url)
    if stream_url:
        play_video(url=stream_url, referer=url)
    else:
        xbmcgui.Dialog().notification('Einthusan', 'Failed to resolve video link', xbmcgui.NOTIFICATION_ERROR)


# --- KUTTYMOVIES ---
@plugin.route('/kuttymovies')
def kuttymovies_index():
    menus = kuttymovies.get_menus()
    for m in menus:
        item = xbmcgui.ListItem(m['name'])
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(kuttymovies_movies, url=m['url']), item, isFolder=True)
    
    # Place Search at the bottom
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(search, provider='kuttymovies'), xbmcgui.ListItem('[COLOR yellow][B]Search...[/B][/COLOR]'), isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/kuttymovies/movies')
def kuttymovies_movies(url=None):
    if not url:
        url = plugin.args.get('url')[0]
    result = kuttymovies.get_movies(url)
    if isinstance(result, tuple):
        movies, next_page = result
    else:
        movies, next_page = result, None
    for m in movies:
        item = xbmcgui.ListItem(m['name'])
        art = {'fanart': FANART_PATH}
        if m.get('thumbnail'):
            art.update({'thumb': m['thumbnail'], 'icon': m['thumbnail']})
        item.setArt(art)
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(kuttymovies_players, url=m['url'], title=m['name']), item, isFolder=True)
    if next_page:
        item = xbmcgui.ListItem("Next Page >>")
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(kuttymovies_movies, url=next_page), item, isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/kuttymovies/players')
def kuttymovies_players():
    url = plugin.args.get('url')[0]
    title = plugin.args.get('title', ['Movie'])[0]
    players = kuttymovies.get_players(url)
    for p in players:
        embed_url = p['url']
        # Resolve spirituallifewell player immediately if possible
        stream_url = None
        if 'spirituallifewell' in embed_url:
            stream_url = kuttymovies.resolve_spirituallife_player(embed_url, referer=url)
        
        item = xbmcgui.ListItem(f"{title} - {p['name']}")
        item.setArt({'fanart': FANART_PATH})
        item.setProperty('IsPlayable', 'true')
        final_url = stream_url if stream_url else embed_url
        referer_url = embed_url if stream_url else url
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(play_video, url=final_url, referer=referer_url), item, isFolder=False)
    if not players:
        xbmcgui.Dialog().notification('KuttyMovies', 'No players found for this movie', xbmcgui.NOTIFICATION_WARNING)
    xbmcplugin.endOfDirectory(plugin.handle)


# --- MOVIEBOX ---
@plugin.route('/moviebox')
def moviebox_index():
    menus = moviebox.get_menus()
    for m in menus:
        item = xbmcgui.ListItem(m['name'])
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(moviebox_movies, category=m['url']), item, isFolder=True)
    
    # Place Search at the bottom
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(search, provider='moviebox'), xbmcgui.ListItem('[COLOR yellow][B]Search...[/B][/COLOR]'), isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/moviebox/movies')
def moviebox_movies(category=None):
    if not category:
        category = plugin.args.get('category')[0]
    movies = moviebox.get_movies(category)
    for m in movies:
        item = xbmcgui.ListItem(m['name'])
        art = {'fanart': FANART_PATH}
        if m.get('thumbnail'):
            art.update({'thumb': m['thumbnail'], 'icon': m['thumbnail']})
        item.setArt(art)
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(moviebox_players, url=m['url'], title=m['name']), item, isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/moviebox/players')
def moviebox_players():
    url = plugin.args.get('url')[0]
    title = plugin.args.get('title', ['Movie'])[0]
    players = moviebox.get_players(url)
    for p in players:
        item = xbmcgui.ListItem(f"{title} - {p['name']}")
        item.setArt({'fanart': FANART_PATH})
        item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(play_video, url=p['url'], referer=url), item, isFolder=False)
    if not players:
        xbmcgui.Dialog().notification('MovieBox', 'No players found for this movie', xbmcgui.NOTIFICATION_WARNING)
    xbmcplugin.endOfDirectory(plugin.handle)


# --- TAMILBLISS ---
@plugin.route('/tamilbliss')
def tamilbliss_index():
    menus = tamilbliss.get_menus()
    for m in menus:
        item = xbmcgui.ListItem(m['title'])
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamilbliss_episodes, url=m['url']), item, isFolder=True)
    
    # Place Search at the bottom
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(search, provider='tamilbliss'), xbmcgui.ListItem('[COLOR yellow][B]Search...[/B][/COLOR]'), isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/tamilbliss/episodes')
def tamilbliss_episodes(url=None):
    if not url:
        url = plugin.args.get('url')[0]
    episodes, next_page = tamilbliss.get_episodes(url)
    for e in episodes:
        item = xbmcgui.ListItem(e['title'])
        art = {'fanart': FANART_PATH}
        if e.get('image'):
            art.update({'thumb': e['image'], 'icon': e['image']})
        item.setArt(art)
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamilbliss_players, url=e['url'], title=e['title']), item, isFolder=True)
    if next_page:
        item = xbmcgui.ListItem("Next Page >>")
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamilbliss_episodes, url=next_page), item, isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/tamilbliss/players')
def tamilbliss_players():
    url = plugin.args.get('url')[0]
    title = plugin.args.get('title')[0]
    players = tamilbliss.get_players(url)
    
    if not players:
        xbmcgui.Dialog().ok('SivaDelight', 'No players found on this page. Link extraction updates might be needed.')

    for p in players:
        item = xbmcgui.ListItem(f"{title} - {p['title']}")
        item.setArt({'fanart': FANART_PATH})
        item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(play_video, url=p['url'], referer=url), item, isFolder=False)
    xbmcplugin.endOfDirectory(plugin.handle)
    
# --- TAMILDHOOL ---
@plugin.route('/tamildhool')
def tamildhool_index():
    channels = tamildhool.get_channels()
    for c in channels:
        item = xbmcgui.ListItem(c['title'])
        art = {'fanart': FANART_PATH}
        if c.get('icon'):
            art.update({'icon': os.path.join(IMG_DIR, c['icon']), 'thumb': os.path.join(IMG_DIR, c['icon'])})
        item.setArt(art)
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamildhool_subcategories, channel_id=c['id']), item, isFolder=True)
    
    # Place Search at the bottom
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(search, provider='tamildhool'), xbmcgui.ListItem('[COLOR yellow][B]Search...[/B][/COLOR]'), isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/tamildhool/channel/<channel_id>')
def tamildhool_subcategories(channel_id):
    subs = tamildhool.get_subcategories(channel_id)
    for s in subs:
        item = xbmcgui.ListItem(s['title'])
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamildhool_items, url=s['url']), item, isFolder=True)
    
    # Place Search at the bottom
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(search, provider='tamildhool'), xbmcgui.ListItem('[COLOR yellow][B]Search...[/B][/COLOR]'), isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/tamildhool/items')
def tamildhool_items(url=None):
    if not url:
        url = plugin.args.get('url')[0]
    items, next_page = tamildhool.get_items(url)
    for i in items:
        item = xbmcgui.ListItem(i['title'])
        art = {'fanart': FANART_PATH}
        if i.get('image'):
            art.update({'thumb': i['image'], 'icon': i['image']})
        item.setArt(art)
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamildhool_players, url=i['url'], title=i['title']), item, isFolder=True)
    if next_page:
        item = xbmcgui.ListItem("Next Page >>")
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(tamildhool_items, url=next_page), item, isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/tamildhool/players')
def tamildhool_players():
    url = plugin.args.get('url')[0]
    title = plugin.args.get('title')[0]
    players = tamildhool.get_videos(url)
    for p in players:
        item = xbmcgui.ListItem(f"{title} - {p['title']}")
        item.setArt({'fanart': FANART_PATH})
        item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(play_video, url=p['url'], referer=url), item, isFolder=False)
    xbmcplugin.endOfDirectory(plugin.handle)
    
# --- meWATCH ---
@plugin.route('/mewatch')
def mewatch_index():
    # Helper for specific Vasantham Live TV (Corrected ID: 97096)
    v_item = xbmcgui.ListItem('[B][COLOR springgreen]VASANTHAM LIVE TV[/COLOR][/B]')
    v_item.setArt({'fanart': FANART_PATH})
    v_item.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(mewatch_vasantham), v_item, isFolder=False)
    
    # Specific Vasantham Drama Collection (ID: 137888)
    d_item = xbmcgui.ListItem('[B][COLOR yellow]Vasantham Dramas[/COLOR][/B]')
    d_item.setArt({'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(mewatch_list, list_id='137888'), d_item, isFolder=True)
    
    # Vasantham Entertainment (ID: 137890)
    e_item = xbmcgui.ListItem('[B][COLOR yellow]Vasantham Entertainment[/COLOR][/B]')
    e_item.setArt({'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(mewatch_list, list_id='137890'), e_item, isFolder=True)

    # Tamil Flix Fiesta (Movies/Specials) (ID: 527597)
    f_item = xbmcgui.ListItem('[B][COLOR yellow]Tamil Flix Fiesta[/COLOR][/B]')
    f_item.setArt({'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(mewatch_list, list_id='527597'), f_item, isFolder=True)
    
    # Tamil Movies (ID: 137892)
    m_item = xbmcgui.ListItem('[B][COLOR yellow]Tamil Movies[/COLOR][/B]')
    m_item.setArt({'fanart': FANART_PATH})
    xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(mewatch_list, list_id='137892'), m_item, isFolder=True)
    
    # Dynamic Categories from the Tamil page
    provider = mewatch.MeWatchProvider()
    categories = provider.get_categories()
    for cat in categories:
        # Filter out duplicates we already added manually
        if cat['id'] in ['137888', '137890', '527597', '137892']:
            continue
        item = xbmcgui.ListItem(cat['title'])
        item.setArt({'fanart': FANART_PATH})
        xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(mewatch_list, list_id=cat['id']), item, isFolder=True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/mewatch/list/<list_id>')
def mewatch_list(list_id):
    provider = mewatch.MeWatchProvider()
    items = provider.get_list_items(list_id)
    for i in items:
        item = xbmcgui.ListItem(i['title'])
        art = {'fanart': FANART_PATH}
        if i.get('image'):
            art.update({'thumb': i['image'], 'icon': i['image']})
        item.setArt(art)
        
        # Determine if it's a playable item or a folder (show/series/season)
        is_folder = i['type'] in ['series', 'show', 'season'] or 'series' in i['type'] or 'show' in i['type']
        
        if is_folder:
            xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(mewatch_children, item_id=i['id']), item, isFolder=True)
        else:
            item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(mewatch_play, item_id=i['id']), item, isFolder=False)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/mewatch/children/<item_id>')
def mewatch_children(item_id):
    provider = mewatch.MeWatchProvider()
    items = provider.get_item_children(item_id)
    for i in items:
        item = xbmcgui.ListItem(i['title'])
        art = {'fanart': FANART_PATH}
        if i.get('image'):
            art.update({'thumb': i['image'], 'icon': i['image']})
        item.setArt(art)
        
        # If it's a season, it's a folder. If it's an episode, it's playable.
        is_folder = i['type'] in ['season', 'series', 'show']
        if is_folder:
            xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(mewatch_children, item_id=i['id']), item, isFolder=True)
        else:
            item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(plugin.handle, plugin.url_for(mewatch_play, item_id=i['id']), item, isFolder=False)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/mewatch/play/<item_id>')
def mewatch_play(item_id):
    provider = mewatch.MeWatchProvider()
    stream_url = provider.get_stream_url(item_id)
    if stream_url:
        path = stream_url + "|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, Gecko) Chrome/119.0.0.0 Safari/537.36&Referer=https://www.mewatch.sg/"
        play_item = xbmcgui.ListItem(path=path)
        xbmcplugin.setResolvedUrl(plugin.handle, True, listitem=play_item)
    else:
        xbmcgui.Dialog().notification('meWATCH', 'Failed to resolve manifest URL', xbmcgui.NOTIFICATION_ERROR)

@plugin.route('/mewatch/live/vasantham')
def mewatch_vasantham():
    provider = mewatch.MeWatchProvider()
    # Fixed ID for Vasantham Live corrected to 97096
    stream_url = provider.get_stream_url("97096")
    if stream_url:
        path = stream_url + "|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36&Referer=https://www.mewatch.sg/"
        play_item = xbmcgui.ListItem(path=path)
        xbmcplugin.setResolvedUrl(plugin.handle, True, listitem=play_item)
    else:
        xbmcgui.Dialog().notification('meWATCH', 'Vasantham Live currently unavailable', xbmcgui.NOTIFICATION_WARNING)


# --- PLAY ---
@plugin.route('/play')
def play_video():
    url = plugin.args.get('url')[0]
    referer = plugin.args.get('referer', [None])[0]
    
    xbmc.log(f"SivaDelight resolving: {url} (Referer: {referer})", xbmc.LOGINFO)
    
    resolved_url = resolvers.resolve_url(url, referer=referer, depth=0)
    
    # Handle Cloudflare-blocked player4me
    if resolved_url == "PLAYER4ME_CF_BLOCKED":
        xbmcgui.Dialog().ok(
            'TamilYogi 2 — Player Blocked',
            'This movie uses [B]Player4Me[/B] which requires a real browser to load.[CR][CR]'
            'Please open the movie link in your browser to watch:[CR]'
            f'[I]{referer or url}[/I]'
        )
        xbmcplugin.setResolvedUrl(plugin.handle, False, listitem=xbmcgui.ListItem())
        return
    
    if not resolved_url or resolved_url == url:
        # If it didn't resolve, but we have a referer, try manually appending Kodi headers
        if referer:
            path = url + f"|Referer={referer}&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36"
            xbmc.log(f"SivaDelight playing with manual headers: {path}", xbmc.LOGINFO)
            play_item = xbmcgui.ListItem(path=path)
        else:
            xbmcgui.Dialog().ok('SivaDelight', 'Unable to resolve video link. Please try another player or check the log.')
            return
    else:
        xbmc.log(f"SivaDelight playing: {resolved_url}", xbmc.LOGINFO)
        play_item = xbmcgui.ListItem(path=resolved_url)
        
    xbmcplugin.setResolvedUrl(plugin.handle, True, listitem=play_item)

@plugin.route('/clear_cache')
def clear_cache():
    import os
    import shutil
    import xbmcaddon
    
    # Get the profile path correctly using xbmcaddon
    addon = xbmcaddon.Addon()
    try:
        # Use xbmcvfs.translatePath for modern Kodi compatibility
        cache_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        
        if os.path.exists(cache_path):
            for filename in os.listdir(cache_path):
                # Don't delete settings or the directory itself
                if filename == 'settings.xml':
                    continue
                
                file_path = os.path.join(cache_path, filename)
                try:
                    if os.path.isfile(file_path) or os.path.islink(file_path):
                        os.unlink(file_path)
                    elif os.path.isdir(file_path):
                        shutil.rmtree(file_path)
                except Exception as e:
                    xbmc.log(f"SivaDelight Clear Cache Skip: {file_path} ({str(e)})", xbmc.LOGDEBUG)
            
            xbmcgui.Dialog().notification('SivaDelight', 'Cache Cleared Successfully!', xbmcgui.NOTIFICATION_INFO, 3000)
            xbmc.executebuiltin('Container.Refresh')
        else:
            xbmcgui.Dialog().notification('SivaDelight', 'No cache found to clear.', xbmcgui.NOTIFICATION_INFO, 3000)
            
    except Exception as e:
        xbmc.log(f"SivaDelight Clear Cache Error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok('SivaDelight', f'Error clearing cache: {str(e)}')

@plugin.route('/search/<provider>')
def search(provider):
    query = xbmcgui.Dialog().input('Search SivaDelight', type=xbmcgui.INPUT_ALPHANUM)
    if not query:
        return
        
    query_encoded = urllib.parse.quote_plus(query)
    
    if provider == 'tamilgun':
        url = f"https://tamilgun.now/?s={query_encoded}"
        return tamilgun_movies(url)
    elif provider == 'movierulz':
        url = f"https://www.5movierulz.viajes/?s={query_encoded}"
        return movierulz_movies(url)
    elif provider == 'tamilyogi' or provider == 'tamilyogi2':
        url = f"https://tamilyogi.cx/?s={query_encoded}"
        if provider == 'tamilyogi2':
             return tamilyogi2_movies(url)
        return tamilyogi_movies(url)
    elif provider == 'gomovies':
        url = f"https://ww10.0gomovies.com.pk/?s={query_encoded}"
        return gomovies_movies(url)
    elif provider == 'kuttymovies':
        url = f"https://1kuttymovies.pro/?s={query_encoded}"
        return kuttymovies_movies(url)
    elif provider == 'arivumani':
        url = f"https://arivumani.net/?s={query_encoded}"
        return arivumani_episodes(url)
    elif provider == 'tamildhool':
        url = f"https://www.tamildhool.tech/?s={query_encoded}"
        return tamildhool_items(url)
    elif provider == 'einthusan':
        # Einthusan search needs language context, defaulting to tamil for now
        url = f"https://einthusan.tv/movie/results/?lang=tamil&query={query_encoded}"
        return einthusan_movies(url)
    elif provider == 'moviebox':
        # MovieBox search using their web URL, though API might be better
        url = f"https://moviebox.ph/web/search-results?keyword={query_encoded}"
        return moviebox_movies(category=url)
    elif provider == 'tamilbliss':
        url = f"https://www.tamilbliss.ru/?s={query_encoded}"
        return tamilbliss_episodes(url)
    elif provider == 'tamilbulb':
        url = f"https://tamilbulb.icu/?s={query_encoded}"
        return tamilbulb_movies(url)
        
    xbmcgui.Dialog().notification('Search', 'Provider not supported yet', xbmcgui.NOTIFICATION_ERROR)

if __name__ == '__main__':
    plugin.run()
