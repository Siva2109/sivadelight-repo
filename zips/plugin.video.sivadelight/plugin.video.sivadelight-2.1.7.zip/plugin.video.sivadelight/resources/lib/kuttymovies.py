"""
KuttyMovies scraper for plugin.video.sivadelight
Site: https://1kuttymovies.pro
WordPress DooPlay theme - movie list + direct iframe player with NEXT_DATA stream URL
"""
import re
import json
from bs4 import BeautifulSoup
from resources.lib.utils import get_html

BASE_URL = "https://1kuttymovies.pro"

def get_menus():
    return [
        {'name': 'Tamil Movies', 'url': f'{BASE_URL}/languages/tamil/'},
        {'name': 'Latest Movies', 'url': f'{BASE_URL}/movie/'},
        {'name': 'Tamil Dubbed', 'url': f'{BASE_URL}/?s=Tamil+Dubbed'},
        {'name': 'Action & Adventure', 'url': f'{BASE_URL}/genres/action-adventure/'},
        {'name': 'Drama', 'url': f'{BASE_URL}/genres/drama/'},
        {'name': 'Mystery', 'url': f'{BASE_URL}/genres/mystery/'},
    ]

def get_movies(url):
    """
    Returns list of dicts: {name, url, thumbnail}
    DooPlay theme uses .cpt-item links and article.TPost for movie items.
    """
    html = get_html(url, referer=BASE_URL, verify=False)
    if not html:
        return [], None

    soup = BeautifulSoup(html, 'html.parser')
    movies = []

    # New pattern - look for movie links in articles or .cpt-item
    items = soup.find_all(['article', 'div'], class_=re.compile(r'item|TPost'))
    if not items:
        # Fallback to search results or simple links
        items = soup.find_all('a', class_='cpt-item')
    
    if not items:
        # Last resort: generic article find
        items = soup.find_all('article')

    for item in items:
        link = item.find('a', href=True) if item.name != 'a' else item
        if not link:
            continue
        href = link.get('href', '')
        if '/movie/' not in href:
            continue

        # Get title
        title_el = item.find(['h2', 'h3', 'span'], class_=re.compile(r'title|name'))
        if not title_el:
             title_el = item.find(['h2', 'h3'])
             
        title = title_el.get_text(strip=True) if title_el else link.get('title', '') or link.get_text(strip=True)

        # Get thumbnail
        img = item.find('img')
        thumb = ''
        if img:
            thumb = img.get('data-src') or img.get('src') or ''

        if href and title:
            movies.append({'name': title, 'url': href, 'thumbnail': thumb})

    # Find next page
    next_page = None
    pagination = soup.find('div', class_='pagination')
    if pagination:
        next_el = pagination.find('a', class_=re.compile(r'next|nav-next'))
        if next_el:
            next_page = next_el.get('href')
        else:
            # Look for current active and find next sibling
            active = pagination.find(['span', 'a'], class_='current')
            if active:
                next_tag = active.find_next_sibling('a')
                if next_tag:
                    next_page = next_tag.get('href')

    return movies, next_page

def get_players(url):
    """
    Returns list of player dicts: {name, url}
    KuttyMovies embeds player3.spirituallifewell.com iframes. 
    """
    import xbmc
    xbmc.log(f"KuttyMovies fetching players from: {url}", xbmc.LOGINFO)
    html = get_html(url, referer=BASE_URL, verify=False)
    if not html:
        xbmc.log("KuttyMovies: Failed to fetch movie page", xbmc.LOGERROR)
        return []

    soup = BeautifulSoup(html, 'html.parser')
    players = []
    seen = set()
    
    # Try finding buttons in .player-tabs
    tabs = soup.find_all('button', class_=re.compile(r'player-tab'))
    for tab in tabs:
        label = tab.get_text(strip=True) or f"Server {len(players)+1}"
        # Often the iframe source is in a data attribute or we need to find the corresponding frame
        players.append({'name': label, 'url': url}) # Placeholder if we can't find direct iframe

    # Find all iframes
    iframes = soup.find_all('iframe')
    for iframe in iframes:
        src = iframe.get('src', '')
        if not src or src in seen:
            continue
        if 'spirituallifewell' in src or 'player' in src or 'embed' in src:
            seen.add(src)
            players.append({'name': f"Server {len(players)+1}", 'url': src})

    # If we found no direct iframes, search raw HTML for iframe patterns
    if not players:
        iframe_matches = re.findall(r'<iframe[^>]*src=["\']([^"\']+)["\']', html)
        for src in iframe_matches:
            if src not in seen:
                seen.add(src)
                players.append({'name': f"Server {len(players)+1}", 'url': src})

    xbmc.log(f"KuttyMovies found {len(players)} players", xbmc.LOGINFO)
    return players

def resolve_spirituallife_player(embed_url, referer=None):
    """
    Resolves player3.spirituallifewell.com/embed/{id} to a direct stream URL.
    """
    import xbmc
    try:
        xbmc.log(f"KuttyMovies resolving SpiritualLife: {embed_url}", xbmc.LOGINFO)
        # Use simple User-Agent as browser showed safety filters on Chrome-like UA
        headers = {'User-Agent': 'Mozilla/5.0'} 
        html = get_html(embed_url, headers=headers, referer=referer or BASE_URL, verify=False)
        if not html:
            return None

        # Try to find m3u8 directly in HTML first (sometimes it's in a script)
        m3u8_match = re.search(r'["\'](https?://[^"\']+\.m3u8[^"\']*)["\']', html)
        if m3u8_match:
            return m3u8_match.group(1)

        # Extract __NEXT_DATA__ JSON
        match = re.search(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', html, re.DOTALL)
        if not match:
            return None

        data = json.loads(match.group(1))
        
        # Search recursively for urlStream or any m3u8 link in the JSON
        def find_stream(obj):
            if isinstance(obj, dict):
                for k, v in obj.items():
                    if k in ('urlStream', 'stream', 'url', 'file', 'src') and isinstance(v, str) and 'm3u8' in v:
                        return v
                    res = find_stream(v)
                    if res: return res
            elif isinstance(obj, list):
                for item in obj:
                    res = find_stream(item)
                    if res: return res
            return None

        stream_url = find_stream(data)
        if stream_url:
            xbmc.log(f"KuttyMovies resolved stream: {stream_url[:100]}", xbmc.LOGINFO)
            return stream_url
            
    except Exception as e:
        xbmc.log(f"KuttyMovies SpiritualLife resolve error: {str(e)}", xbmc.LOGERROR)
    
    return None
