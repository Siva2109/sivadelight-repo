import re
from bs4 import BeautifulSoup
from resources.lib.utils import get_html

BASE_URL = "https://www.5movierulz.viajes"

def get_menus():
    menus = [
        {'title': 'Bollywood', 'url': f'{BASE_URL}/category/bollywood-featured/'},
        {'title': 'Telugu', 'url': f'{BASE_URL}/category/telugu-featured/'},
        {'title': 'Tamil', 'url': f'{BASE_URL}/category/tamil-featured/'},
        {'title': 'Malayalam', 'url': f'{BASE_URL}/category/malayalam-featured/'},
        {'title': 'Hollywood', 'url': f'{BASE_URL}/category/hollywood-featured/'}, # User mentioned hollywood-featured
        {'title': 'Dubbed', 'url': f'{BASE_URL}/language/tamil-dubbed/'}
    ]
    return menus

def get_movies(category_url):
    html = get_html(category_url, verify=False)
    soup = BeautifulSoup(html, "html.parser")
    movies = []
    
    # Items
    items = soup.find_all('div', class_='cont_display')
    seen_urls = set()
    for item in items:
        a_tag = item.find('a')
        if not a_tag:
            continue
            
        url = a_tag.get('href')
        if not url or url in seen_urls:
            continue
            
        title = a_tag.get('title', '')
        if not title:
            # try to find b tag for title
            b = a_tag.find('b')
            if b:
                title = b.text.strip()
                
        img_url = ""
        img_tag = a_tag.find('img')
        if img_tag:
            img_url = img_tag.get('src')
            if img_url and img_url.startswith('//'):
                img_url = 'https:' + img_url
                
        if url and title:
            movies.append({
                'title': title,
                'url': url,
                'image': img_url
            })
            
    # Pagination
    next_page = None
    next_tag = soup.find('a', class_='next page-numbers')
    if next_tag and next_tag.get('href'):
        next_page = next_tag.get('href')
        
    return movies, next_page

def get_players(movie_url):
    html = get_html(movie_url, verify=False)
    soup = BeautifulSoup(html, "html.parser")
    players = []
    seen_urls = set()
    
    entry = soup.find('div', class_='entry-content')
    if entry:
        # First pass: try specifically structured server labels in <p> tags
        for p in entry.find_all('p'):
            if 'Watch Online' in p.text:
                p_links = p.find_all('a')
                for link in p_links:
                    href = link.get('href', '').strip().replace('\r', '').replace('\n', '')
                    if not href.startswith('http') or BASE_URL in href or href in seen_urls:
                        continue
                    
                    # Extract server name from the parent <p> text
                    full_text = p.get_text(separator='|', strip=True) 
                    parts = full_text.split('|')
                    server_label = ""
                    for part in parts:
                        if 'Watch Online' in part and ('–' in part or '-' in part):
                            temp = part.replace('Watch Online', '').replace('', '').strip()
                            server_label = re.split(r'[–-]', temp)[-1].strip()
                            break
                    
                    if not server_label or len(server_label) > 30:
                        # Fallback to general text cleaning if it looks like a whole sentence
                        server_label = p.text.replace(link.text, '').replace('Watch Online', '').replace('–', '').strip()
                        server_label = re.sub(r'^.*?\)\s*', '', server_label) # Skip title prefix
                    
                    if not server_label or len(server_label) > 30:
                        domain_match = re.search(r'https?://(?:www\.)?([^/.]+)', href)
                        server_label = domain_match.group(1).capitalize() if domain_match else "Video Server"

                    players.append({
                        'title': server_label,
                        'url': href,
                        'is_iframe': False
                    })
                    seen_urls.add(href)

        # Second pass: catch any other links that might have been missed
        links = entry.find_all('a')
        for link in links:
            href = link.get('href', '').strip().replace('\r', '').replace('\n', '')
            if not href or not href.startswith('http') or BASE_URL in href or href in seen_urls:
                continue
            
            # Filter and label
            if any(x in href.lower() for x in ['vcdn', 'uperbox', 'easysyncr', 'drop', 'hglink', 'mino', 'uqload', 'stream', 'dood', 'voe', 'mixdrop', 'filelions']):
                domain_match = re.search(r'https?://(?:www\.)?([^/.]+)', href)
                label = domain_match.group(1).capitalize() if domain_match else "Video Server"
                players.append({
                    'title': label,
                    'url': href,
                    'is_iframe': False
                })
                seen_urls.add(href)
    
    return players
