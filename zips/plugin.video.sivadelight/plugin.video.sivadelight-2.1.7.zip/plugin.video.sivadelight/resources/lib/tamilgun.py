import re
from bs4 import BeautifulSoup
from resources.lib.utils import get_html

BASE_URL = "https://tamilgun.now"

def get_menus():
    menus = [
        {'title': 'New Movies', 'url': f'{BASE_URL}/movies/'},
        {'title': 'HD Movies', 'url': f'{BASE_URL}/video-category/hd-movies/'},
        {'title': 'Dubbed Movies', 'url': f'{BASE_URL}/video-category/dubbed-movies/'},
        {'title': 'Web Series', 'url': f'{BASE_URL}/video-category/web-series/'},
        {'title': 'Malayalam', 'url': f'{BASE_URL}/video-category/malayalam/'}
    ]
    return menus

def get_movies(category_url):
    html = get_html(category_url, verify=False)
    if not html:
        return [], None
    soup = BeautifulSoup(html, "html.parser")
    movies = []
    
    # Tamilgun typical structure
    items = soup.find_all(['div', 'article'], class_=re.compile(r'post|item'))
    seen_urls = set()
    
    for item in items:
        a_tag = item.find('a', class_=re.compile(r'title|listing')) or item.find('a')
        if not a_tag:
            continue
            
        url = a_tag.get('href')
        if not url or url == '#' or '/video-category/' in url:
            continue
            
        if url.startswith('/'):
            url = BASE_URL + url
            
        if url in seen_urls:
            continue
            
        title = ""
        title_tag = item.find(['h1', 'h2', 'h3', 'div'], class_=re.compile(r'title'))
        if title_tag:
            title = title_tag.text.strip()
        elif a_tag.get('title'):
            title = a_tag.get('title')
        else:
            title = a_tag.text.strip()
            
        if not title or len(title) < 2:
            continue
            
        img_url = ""
        img_tag = item.find('img')
        if img_tag:
            img_url = img_tag.get('src') or img_tag.get('data-src') or ""
            if img_url.startswith('//'):
                img_url = 'https:' + img_url
            elif img_url.startswith('/'):
                img_url = BASE_URL + img_url
                
        movies.append({
            'title': title,
            'url': url,
            'image': img_url
        })
        seen_urls.add(url)
        
    # extract next page link if exists
    next_page = None
    next_tag = soup.find('a', class_=re.compile(r'next|page-numbers'))
    if next_tag and next_tag.get('href'):
        next_page = next_tag.get('href')
        if next_page.startswith('/'):
            next_page = BASE_URL + next_page
        
    return movies, next_page

def get_players(movie_url):
    html = get_html(movie_url, verify=False)
    if not html:
        return []
    soup = BeautifulSoup(html, "html.parser")
    players = []
    seen_urls = set()
    
    # 1. Look for explicit Player links
    a_tags = soup.find_all('a')
    for a in a_tags:
        text = a.text.strip()
        if 'Player' in text:
            url = a.get('href')
            if not url:
                continue
            
            # Skip anchor-only links or links that are just the page itself
            if url.startswith('#') or url == movie_url:
                continue
                
            if url not in seen_urls:
                # Ensure it's not an internal category or home link
                if BASE_URL in url and ('video-category' in url or url == BASE_URL + '/'):
                    continue
                players.append({
                    'title': text,
                    'url': url,
                    'is_iframe': False
                })
                seen_urls.add(url)
    
    # 2. Look for iframes, but be very selective
    iframes = soup.find_all('iframe')
    playallu_links = []
    other_iframes = []
    
    for iframe in iframes:
        src = iframe.get('src') or iframe.get('data-src')
        if not src:
            continue
        
        if src.startswith('//'):
            src = 'https:' + src
            
        if src in seen_urls:
            continue
            
        # Check for playallu and compatible mirrors (hq, 6str, 9stream)
        if any(x in src.lower() for x in ['playallu', 'playhq', '6str', '9str', '9stream', 'vignesh']):
            playallu_links.append(src)
        # Check for other known hosts
        elif any(x in src.lower() for x in ['vcdn', 'uperbox', 'streamwish', 'uqload', 'dood', 'voe', 'mixdrop']):
            other_iframes.append(src)

    # Pick the best PlayAllu link (prefer .xyz)
    if playallu_links:
        for idx, link in enumerate(playallu_links):
            title = 'PlayAllu Player' if len(playallu_links) == 1 else f'PlayAllu Player {idx+1}'
            players.append({
                'title': title,
                'url': link,
                'is_iframe': True
            })
            seen_urls.add(link)

    # Add other iframes
    for src in other_iframes:
        if src not in seen_urls:
            players.append({
                'title': f'Player {len(players) + 1}',
                'url': src,
                'is_iframe': True
            })
            seen_urls.add(src)
            
    return players
