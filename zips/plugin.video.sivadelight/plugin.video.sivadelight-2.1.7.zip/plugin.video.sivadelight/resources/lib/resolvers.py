import re
import json
import base64
import hashlib
import binascii
from bs4 import BeautifulSoup
from resources.lib.utils import get_html
from resources.lib import jscrypto
import urllib.parse
import xbmc

try:
    import resolveurl
except ImportError:
    resolveurl = None

def pencode(c, m):
    i = jscrypto.encode(c, m)
    f = base64.b64decode(i)
    i = binascii.hexlify(f)
    if isinstance(i, bytes):
        return i.decode('utf-8')
    return i

def pdecode(i, f):
    y = binascii.unhexlify(i)
    b = base64.b64encode(y)
    k = jscrypto.decode(b, f)
    return k

def resolve_playallu(eurl, referer):
    """
    Decryption handshake for playallu.
    eurl: the player link (e.g. https://play.playallu.com/...)
    referer: the page containing the player (e.g. tamilgun)
    """
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',
            'Referer': referer
        }
        
        # 1. Get the player page
        html = get_html(eurl, referer=referer, verify=False)
        if not html:
            return None
            
        # 2. Extract encrypted IDs and API domain
        idfile_enc = re.findall(r'''idfile_enc\s*=\s*["']([^"']+)''', html)
        iduser_enc = re.findall(r'''idUser_enc\s*=\s*["']([^"']+)''', html)
        dev_play = re.findall(r'''DEV_PLAY\s*=\s*["']([^"']*)''', html)
        api_domain = re.findall(r'''DOMAIN_API\s*=\s*["']([^"']+)''', html)
        
        if not (idfile_enc and iduser_enc and api_domain):
            return None
            
        idfile_enc = idfile_enc[0]
        iduser_enc = iduser_enc[0]
        dev_play = dev_play[0] if dev_play else ""
        api_url = api_domain[0]
        
        # 3. Decrypt IDs
        idfile_dec = pdecode(idfile_enc, 'jcLycoRJT6OWjoWspgLMOZwS3aSS0lEn')
        iduser_dec = pdecode(iduser_enc, 'PZZ3J3LDbLT0GY7qSA5wW5vchqgpO36O')
        
        # 4. Prepare request data
        ref_root = urllib.parse.urljoin(referer, '/')
        pdata = {
            "idfile": idfile_dec,
            "iduser": iduser_dec,
            "domain_play": "https://my.9stream.net" if dev_play == "thang" else ref_root.rstrip('/'),
            "platform": "Win32",
            "hlsSupport": True
        }
        
        # 5. Encode data for API
        z = pencode(json.dumps(pdata), 'vlVbUQhkOhoSfyteyzGeeDzU0BHoeTyZ')
        # Ensure z is str for concatenation, then encode for md5
        md5_input = (z + 'KRWN3AdgmxEMcd2vLN1ju9qKe8Feco5h').encode('utf-8')
        w = binascii.hexlify(hashlib.md5(md5_input).digest()).decode('utf-8')
        
        post_data = {'data': f"{z}|{w}"}
        pref = urllib.parse.urljoin(eurl, '/')
        
        # 6. Call API to get stream link
        headers.update({'Referer': eurl, 'Origin': pref.rstrip('/')})
        # Note: get_html needs to handle POST if we want to use it, but for now let's use requests via utils if possible
        # Or just use the already available requests via imports in utils.
        from resources.lib.utils import requests
        
        response = requests.post(api_url + '/playiframe', headers=headers, data=post_data, verify=False, timeout=10)
        if response.status_code == 200:
            result = response.json()
            enc_stream = result.get('data')
            if enc_stream:
                # 7. Final decryption of the stream URL
                stream_url = pdecode(enc_stream, 'oJwmvmVBajMaRCTklxbfjavpQO7SZpsL')
                # Append headers for Kodi playback
                is_android = xbmc.getCondVisibility('system.platform.android')
                # Adding both verifypeer and verifyhost for strict Android builds
                extra = '&verifypeer=false&verifyhost=false' if is_android else ''
                stream_url += f'|Referer={pref}&User-Agent={headers["User-Agent"]}{extra}'
                return stream_url
                
    except Exception as e:
        xbmc.log(f"SivaDelight PlayAllu Error: {str(e)}", xbmc.LOGERROR)
        
    return None

def unpack_eval(html):
    """
    Unpacks standard JS eval(function(p,a,c,k,e,d)...) obfuscation.
    Returns the unpacked javascript string.
    """
    try:
        # Some packers use 'return p}(' and some use 'return p} ('
        packer_match = re.search(r'eval\(function\(p,a,c,k,e,[\w_]+\).*?return\s+p}\s*\(\s*\'(.*?)\'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*\'(.*?)\'\.split', html, re.DOTALL)
        if not packer_match:
            return ""
            
        p = packer_match.group(1).replace("\\'", "'").replace('\\"', '"').replace('\\\\', '\\')
        a = int(packer_match.group(2))
        c = int(packer_match.group(3))
        k = packer_match.group(4).split('|')
        
        def e_func(c_val):
            res = ""
            if c_val == 0: res = "0"
            else:
                while c_val > 0:
                    rem = c_val % 36
                    c_val = c_val // 36
                    if rem < 10: res = str(rem) + res
                    else: res = chr(rem - 10 + ord('a')) + res
            return res

        while c > 0:
            c -= 1
            if k[c]:
                p = re.sub('\\b' + str(e_func(c)) + '\\b', k[c], p)
        return p
    except Exception as e:
        xbmc.log(f"SivaDelight Unpack Error: {str(e)}", xbmc.LOGERROR)
        return ""

def unpack_eval_v2(p, a, c, k, e=None, d=None):
    """Robust packer unpacker with base62 support"""
    def baseN(num, b):
        tab = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
        if num == 0: return tab[0]
        res = ""
        while num > 0:
            res = tab[num % b] + res
            num //= b
        return res

    for i in range(c - 1, -1, -1):
        if k[i]:
            p = re.sub(r'\b' + baseN(i, a) + r'\b', k[i], p)
    return p

def resolve_showdetails(url, referer=None):
    """
    Resolver for showdetails.org, searchping.com, dstshndisk.showdetails.org
    """
    try:
        from resources.lib.utils import requests, get_html
        s = requests.Session()
        s.verify = False
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        
        # Stage 1: Handle getlink.php or initial redirect
        if 'getlink.php' in url:
            html = s.get(url, headers={'User-Agent': ua, 'Referer': referer}, timeout=10).text
            match = re.search(r'refresh.*?url=(.*?)"', html, re.I)
            if match:
                url = match.group(1).replace('&amp;', '&')
                if url.startswith('/'): url = 'https://blog.showdetails.org' + url
                xbmc.log(f"SivaDelight Showdetails Step 1: {url}", xbmc.LOGINFO)

        # Stage 2: blog.showdetails.org (NEEDS searchping referer)
        if 'blog.showdetails.org' in url:
            # We must use searchping referer to bypass dummy article
            res = s.get(url, headers={'User-Agent': ua, 'Referer': 'https://go.searchping.com/'}, timeout=10)
            html = res.text
            # More generic iframe detection (any .php in hls folder or similar)
            match = re.search(r'iframe.*?src=["\'](https?://dstshndisk\.showdetails\.org/.*?\.php.*?)["\']', html, re.I)
            if match:
                url = match.group(1).replace('&amp;', '&')
                xbmc.log(f"SivaDelight Showdetails Step 2: {url}", xbmc.LOGINFO)
        
        # Stage 3: .php player -> Packed JS
        if '.php' in url and 'showdetails.org' in url:
            html = s.get(url, headers={'User-Agent': ua, 'Referer': 'https://blog.showdetails.org/'}, timeout=10).text
            # More robust packer regex
            packer_match = re.search(r"return\s+p\}\s*\(\s*'(.*?)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'(.*?)'\.split\('\|'\)", html, re.DOTALL)
            if packer_match:
                p, a, c, k = packer_match.groups()
                unpacked = unpack_eval_v2(p, int(a), int(c), k.split('|'))
                
                # Look for sources in unpacked JS
                # Example: src:[{"label":"HD","type":"video/mp4","file":"..."}]
                stream_match = re.search(r'["\']?file["\']?\s*:\s*["\']([^"\']+)["\']', unpacked)
                if stream_match:
                    final_url = stream_match.group(1).replace('\\/', '/')
                    if final_url.startswith('//'): final_url = 'https:' + final_url
                    xbmc.log(f"SivaDelight Showdetails Final: {final_url}", xbmc.LOGINFO)
                    return final_url
                    
        return url
    except Exception as e:
        xbmc.log(f"SivaDelight Showdetails Resolver Error: {str(e)}", xbmc.LOGERROR)
        return url

def resolve_cloudbulb(url, referer):
    """
    Resolver for cloudbulb.space, cdnbulb.com, streambulb.site, byseragui.com
    These usually use eval packing or an AJAX POST to an API.
    """
    try:
        from resources.lib.utils import requests
        s = requests.Session()
        s.verify = False
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Referer': referer if referer else url
        }
        
        # 1. First GET to establish cookies and fetch HTML
        r1 = s.get(url, headers=headers, timeout=10)
        html = r1.text
        if not html: return None
        
        is_android = xbmc.getCondVisibility('system.platform.android')
        extra = '&verifypeer=false&verifyhost=false' if is_android else ''
        headers_str = f"|Referer={url}&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36{extra}"
        
        # 2. Check TG-Cloud specific TOKENS array
        tokens_match = re.search(r'const TOKENS\s*=\s*\[["\']([^"\']+)', html)
        media_base_match = re.search(r'const MEDIA_BASE\s*=\s*["\']([^"\']+)["\']', html)
        if tokens_match and media_base_match:
            token = tokens_match.group(1)
            media_base = media_base_match.group(1)
            return f"{media_base}?id={urllib.parse.quote(token)}&f=.m3u8{headers_str}"
        
        # 3. Check for Direct m3u8 in HTML source (fallback)
        m3u8_match = re.search(r'(https?://[^"\']+\.m3u8[^"\']*)', html)
        if m3u8_match:
            return m3u8_match.group(1) + headers_str
            
        # 3. Handle AJAX API (cdnbulb, cloudbulb often use this now)
        # Type A: cdnbulb uses /player/index.php?data=ID&do=getVideo
        # ID is usually the last part of the URL, e.g., /video/ecf5...
        vid_id_match = re.search(r'/video/([a-zA-Z0-9_]+)', url)
        # Or type B: ty.cloudbulb uses watchit.php?id=ID -> rest-api.php
        ty_id_match = re.search(r'id=([a-zA-Z0-9_~-]+)', url)
        # Type C: byseraguci uses /e/ID
        bys_id_match = re.search(r'/e/([a-zA-Z0-9_]+)', url)
        
        if vid_id_match:
            vid_id = vid_id_match.group(1)
            api_url = urllib.parse.urljoin(url, f'/player/index.php?data={vid_id}&do=getVideo')
            post_data = {'hash': vid_id, 'r': referer if referer else ''}
            
            post_headers = headers.copy()
            post_headers['Referer'] = url
            post_headers['X-Requested-With'] = 'XMLHttpRequest'
            
            r2 = s.post(api_url, headers=post_headers, data=post_data, timeout=10)
            if r2.status_code == 200:
                try:
                    data = r2.json()
                    if 'securedLink' in data:
                        return data['securedLink'] + headers_str
                except:
                    pass
                    
        elif ty_id_match:
            vid_id = ty_id_match.group(1)
            api_url = urllib.parse.urljoin(url, '/rest-api.php')
            post_data = {'action': 'media_detail', 'id': vid_id}
            
            post_headers = headers.copy()
            post_headers['Referer'] = url
            post_headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
            
            r2 = s.post(api_url, headers=post_headers, data=post_data, timeout=10)
            if r2.status_code == 200:
                try:
                    data = r2.json()
                    if 'data' in data and 'stream_url' in data['data']:
                        # stream_url is often relative: vod.php?id=...
                        stream = urllib.parse.urljoin(url, data['data']['stream_url'])
                        # TY-Cloud returns a 302 redirect here which drops Kodi headers.
                        # We must manually follow it in Python first!
                        r3 = s.get(stream, headers=headers, allow_redirects=False, timeout=10)
                        if 'Location' in r3.headers:
                            stream = r3.headers['Location']
                            
                        return stream + headers_str
                except:
                    pass
                    
        elif bys_id_match and 'byseraguci' in url:
            vid_id = bys_id_match.group(1)
            api_url = urllib.parse.urljoin(url, f'/api/videos/{vid_id}')
            r2 = s.get(api_url, headers=headers, timeout=10)
            if r2.status_code == 200:
                try:
                    data = r2.json()
                    pb = data.get('playback')
                    if pb and pb.get('algorithm') == 'AES-256-GCM':
                        import base64
                        def pad_b64url(st):
                            st = st.replace('-', '+').replace('_', '/')
                            while len(st) % 4 != 0: st += '='
                            return st
                        
                        key_bytes = b"".join([base64.b64decode(pad_b64url(k)) for k in pb['key_parts']])
                        iv_bytes = base64.b64decode(pad_b64url(pb['iv']))
                        ciphertext = base64.b64decode(pad_b64url(pb['payload']))
                        
                        success = False
                        try:
                            from Crypto.Cipher import AES
                            actual_ct = ciphertext[:-16]
                            tag = ciphertext[-16:]
                            cipher = AES.new(key_bytes, AES.MODE_GCM, nonce=iv_bytes)
                            decrypted = cipher.decrypt_and_verify(actual_ct, tag)
                            success = True
                        except ImportError:
                            pass
                            
                        if not success:
                            try:
                                from cryptography.hazmat.primitives.ciphers.aead import AESGCM
                                aesgcm = AESGCM(key_bytes)
                                decrypted = aesgcm.decrypt(iv_bytes, ciphertext, None)
                                success = True
                            except ImportError:
                                pass
                                
                        if success:
                            dec_json = json.loads(decrypted.decode('utf-8'))
                            sources = dec_json.get('sources', [])
                            if sources:
                                stream = sources[0].get('url')
                                if stream:
                                    return stream + headers_str
                except Exception as e:
                    xbmc.log(f"SivaDelight Bys-Stream AES Error: {str(e)}", xbmc.LOGERROR)
            
        # 4. Fallback to Unpack eval
        unpacked = unpack_eval(html)
        if unpacked:
            m3u8_match = re.search(r'(https?://[^"\']+\.m3u8[^"\']*)', unpacked)
            if m3u8_match:
                return m3u8_match.group(1) + headers_str
                
            file_match = re.search(r'file["\']\s*:\s*["\'](https?://[^"\']+\.mp4[^"\']*)["\']', unpacked)
            if file_match:
                return file_match.group(1) + headers_str
                
    except Exception as e:
        xbmc.log(f"SivaDelight Cloudbulb Error: {str(e)}", xbmc.LOGERROR)
    return None

def resolve_tamilgun(url, referer):
    """
    Resolver for tamilgun embed links (e.g. tamilgun.life/embed/...)
    These use standard eval packing for their hls stream.
    """
    try:
        html = get_html(url, referer=referer, verify=False)
        if not html: return None
        
        is_android = xbmc.getCondVisibility('system.platform.android')
        extra = '&verifypeer=false&verifyhost=false' if is_android else ''
        headers_str = f"|Referer={url}&User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36{extra}"
        
        # Sometime direct
        m3u8_match = re.search(r'(https?://[^"\']+\.m3u8[^"\']*)', html)
        if m3u8_match:
            return m3u8_match.group(1) + headers_str
            
        unpacked = unpack_eval(html)
        if unpacked:
            m3u8_match = re.search(r'(https?://[^"\']+\.m3u8[^"\']*)', unpacked)
            if m3u8_match:
                return m3u8_match.group(1) + headers_str
                
    except Exception as e:
        xbmc.log(f"SivaDelight Tamilgun Error: {str(e)}", xbmc.LOGERROR)
    return None

def resolve_player4me(url, referer=None):
    """
    Resolver for embedo.player4me.vip
    The player loads via JavaScript and requires a Cloudflare-verified session token.
    Python cannot replicate this without a real browser. We try the API and log the outcome.
    """
    try:
        from resources.lib.utils import requests
        xbmc.log(f"SivaDelight Player4Me resolving: {url}", xbmc.LOGINFO)
        
        # Extract the hash from the URL (e.g. https://embedo.player4me.vip/#3nswz -> 3nswz)
        hash_match = re.search(r'[#?]([a-zA-Z0-9_-]+)$', url)
        if not hash_match:
            return None
        token = hash_match.group(1)
        
        base_url = re.match(r'(https?://[^/]+)', url).group(1)
        api_url = f"{base_url}/api/v1/player?t={token}"
        
        s = requests.Session()
        s.verify = False
        
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'
        page_ref = referer or 'https://tamilyogi.horse/'
        
        # Step 1: GET the player page to obtain any cookies
        page_headers = {
            'User-Agent': ua,
            'Referer': page_ref,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        }
        s.get(f"{base_url}/#{token}", headers=page_headers, timeout=10)
        
        # Step 2: Call the API with any cookies we got
        api_headers = {
            'User-Agent': ua,
            'Referer': f"{base_url}/",
            'Origin': base_url,
            'Accept': 'application/json, text/plain, */*',
        }
        resp = s.get(api_url, headers=api_headers, timeout=10)
        
        xbmc.log(f"SivaDelight Player4Me API status: {resp.status_code}", xbmc.LOGINFO)
        
        if resp.status_code == 200:
            try:
                data = resp.json()
                xbmc.log(f"SivaDelight Player4Me API response: {str(data)[:300]}", xbmc.LOGINFO)
                
                # Check for token invalid (Cloudflare JS challenge requirement)
                if isinstance(data, dict) and data.get('error') == 'Token is invalid':
                    xbmc.log("SivaDelight Player4Me: Token invalid - requires JS execution. Cloudflare protected.", xbmc.LOGWARNING)
                    return "PLAYER4ME_CF_BLOCKED"
                
                # Extract stream URL from successful response
                stream_url = None
                if isinstance(data, dict):
                    for field in ['url', 'stream', 'src', 'hls', 'link', 'file', 'playlist']:
                        if field in data and data[field]:
                            stream_url = data[field]
                            break
                    if not stream_url and 'sources' in data:
                        sources = data['sources']
                        if isinstance(sources, list) and sources:
                            stream_url = sources[0].get('file') or sources[0].get('src') or sources[0].get('url')
                
                if stream_url and ('m3u8' in stream_url or 'mp4' in stream_url):
                    is_android = xbmc.getCondVisibility('system.platform.android')
                    extra = '&verifypeer=false&verifyhost=false' if is_android else ''
                    return stream_url + f'|Referer={base_url}/&User-Agent={ua}{extra}'
                    
            except Exception as json_err:
                xbmc.log(f"SivaDelight Player4Me JSON parse error: {str(json_err)}", xbmc.LOGERROR)
                m3u8_match = re.search(r'(https?://[^\s"\']+\.m3u8[^\s"\']*)', resp.text)
                if m3u8_match:
                    return m3u8_match.group(1) + f'|Referer={base_url}/&User-Agent={ua}'
                    
    except Exception as e:
        xbmc.log(f"SivaDelight Player4Me Error: {str(e)}", xbmc.LOGERROR)
    
    return None

def resolve_spirituallife(url, referer=None):
    """
    Resolver for Spirituallifewell (KuttyMovies).
    """
    try:
        from resources.lib.utils import requests
        # Use simple UA for this one as high-UA sometimes triggers filters
        headers = {'User-Agent': 'Mozilla/5.0', 'Referer': referer or 'https://1kuttymovies.pro/'}
        r = requests.get(url, headers=headers, verify=False, timeout=10)
        html = r.text
        if not html: return None

        # Try __NEXT_DATA__ first
        match = re.search(r'<script id="__NEXT_DATA__" type="application/json">(.*?)</script>', html, re.DOTALL)
        if match:
            data = json.loads(match.group(1))
            
            def find_stream(obj):
                if isinstance(obj, dict):
                    for k, v in obj.items():
                        if k in ('urlStream', 'stream', 'url', 'file', 'src') and isinstance(v, str) and 'm3u8' in v:
                            return v
                        res = find_stream(v)
                        if res: return res
                elif isinstance(obj, list):
                    for item in obj:
                        res = find_stream(item)
                        if res: return res
                return None

            stream_url = find_stream(data)
            if stream_url: return stream_url

        # Fallback to direct regex
        m3u8_match = re.search(r'["\'](https?://[^"\']+\.m3u8[^"\']*)["\']', html)
        if m3u8_match:
            return m3u8_match.group(1)
            
    except Exception as e:
        xbmc.log(f"SivaDelight Spirituallife Error: {str(e)}", xbmc.LOGERROR)
    return None

def resolve_streamwish(url, referer=None):
    """
    Resolver for Streamwish, Vidhide, Uperbox, Minochinos, etc.
    These use 'eval' packing and require strict headers.
    """
    try:
        from resources.lib.utils import requests
        s = requests.Session()
        s.verify = False
        
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'
        headers = {'User-Agent': ua, 'Referer': referer or url}
        
        r = s.get(url, headers=headers, timeout=10)
        html = r.text
        if not html: return None
        
        # Follow refresh meta if present (anti-bot technique)
        refresh = re.search(r'content=["\']0;\s*url=([^"\']+)["\']\s+http-equiv=["\']refresh["\']', html, re.I)
        if refresh:
            url = refresh.group(1)
            if url.startswith('/'):
                url = urllib.parse.urljoin(r.url, url)
            r = s.get(url, headers=headers, timeout=10)
            html = r.text

        origin = re.match(r'(https?://[^/]+)', r.url).group(1)
        headers_str = f"|Referer={r.url}&User-Agent={ua}&Origin={origin}"
        if xbmc.getCondVisibility('system.platform.android'):
            headers_str += '&verifypeer=false&verifyhost=false'

        # Try to find m3u8 in unpacked eval
        unpacked = unpack_eval(html)
        if unpacked:
            m3u8_match = re.search(r'(https?://[^"\']+\.m3u8[^"\']*)', unpacked)
            if m3u8_match:
                return m3u8_match.group(1) + headers_str
        
        # Try finding directly in HTML
        m3u8_match = re.search(r'(https?://[^"\']+\.m3u8[^"\']*)', html)
        if m3u8_match:
            return m3u8_match.group(1) + headers_str
            
    except Exception as e:
        xbmc.log(f"SivaDelight Streamwish Error: {str(e)}", xbmc.LOGERROR)
    return None

def resolve_filelions(url, referer=None):
    """
    Resolver for Filelions, HGLink, Lion.to, etc.
    Handle redirects to final domain (e.g. masukestin.com).
    """
    try:
        from resources.lib.utils import requests
        s = requests.Session()
        s.verify = False
        
        ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'
        headers = {'User-Agent': ua, 'Referer': referer or url}
        
        # Follow redirects to get the real domain (Filelions -> masukestin)
        r = s.get(url, headers=headers, timeout=10)
        html = r.text
        if not html: return None
        
        origin = re.match(r'(https?://[^/]+)', r.url).group(1)
        headers_str = f"|Referer={r.url}&User-Agent={ua}&Origin={origin}"
        if xbmc.getCondVisibility('system.platform.android'):
            headers_str += '&verifypeer=false&verifyhost=false'

        unpacked = unpack_eval(html)
        if unpacked:
            m3u8_match = re.search(r'(https?://[^"\']+\.m3u8[^"\']*)', unpacked)
            if m3u8_match:
                return m3u8_match.group(1) + headers_str
                
    except Exception as e:
        xbmc.log(f"SivaDelight Filelions Error: {str(e)}", xbmc.LOGERROR)
    return None

def resolve_url(url, referer=None, depth=0):
    """
    Main entry point for resolving video links.
    """
    if not url or url.startswith('javascript:'):
        return None
        
    xbmc.log(f"SivaDelight Resolving (Depth {depth}): {url}", xbmc.LOGINFO)

    # 1. Direct Links
    if url.endswith('.mp4') or url.endswith('.m3u8'):
        return url
        
    # 2. PlayAllu Site Specific
    if 'playallu' in url or 'playhq' in url or '6str' in url or '9str' in url:
        if not referer:
            # Guessing referer if missing
            referer = 'https://tamilgun.now/'
        resolved = resolve_playallu(url, referer)
        if resolved:
            return resolved

    # 2b. CloudBulb / CDNBulb / Byseraguci
    if 'cloudbulb' in url or 'cdnbulb' in url or 'streambulb' in url or 'byseraguci' in url:
        resolved = resolve_cloudbulb(url, referer)
        if resolved:
            return resolved

    # 2c. TamilGun Embeds
    if 'tamilgun' in url and '/embed/' in url:
        resolved = resolve_tamilgun(url, referer)
        if resolved:
            return resolved

    # 2d. Player4Me (player4me.vip)
    if 'player4me' in url:
        resolved = resolve_player4me(url, referer)
        if resolved:
            return resolved

    # 2f. Searchping / Showdetails
    if any(x in url for x in ['searchping.com', 'showdetails.org']):
        resolved = resolve_showdetails(url, referer)
        if resolved:
            return resolved

    # 2e. Streamwish / Vidhide / Uperbox / Minochinos / Vidguard
    if any(x in url for x in ['streamwish', 'awish', 'dwish', 'vidhide', 'vidh', 'uperbox', 'minochinos', 'vgembed', 'vidguard']):
        resolved = resolve_streamwish(url, referer)
        if resolved:
            return resolved

    # 2f. Filelions / HGLink / Lion / Masukestin
    if any(x in url for x in ['filelions', 'lion', 'hglink', 'masukestin', 'f-lions']):
        resolved = resolve_filelions(url, referer)
        if resolved:
            return resolved

    # 2g. Spirituallife (KuttyMovies)
    if 'spirituallife' in url:
        resolved = resolve_spirituallife(url, referer)
        if resolved:
            return resolved

    # 3. ResolveURL (External Kodi Module)
    if resolveurl and resolveurl.HostedMediaFile(url).valid_url():
        try:
            return resolveurl.HostedMediaFile(url).resolve()
        except:
            pass

    # 4. Simple Heuristic (Regex on page source)
    html = get_html(url, referer=referer, verify=False)
    if not html:
        return url
        
    xbmc.log(f"SivaDelight Resolver HTML length: {len(html)}", xbmc.LOGDEBUG)
    
    is_android = xbmc.getCondVisibility('system.platform.android')
    extra = '&verifypeer=false&verifyhost=false' if is_android else ''
    # Use a more modern UA and include Origin by default
    ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'
    origin_match = re.match(r'(https?://[^/]+)', url)
    origin = origin_match.group(1) if origin_match else ''
    headers_str = f"|Referer={url}&User-Agent={ua}&Origin={origin}{extra}"
        
    # Look for m3u8 or mp4 in Javascript or meta tags
    patterns = [
        r'src\s*[:=]\s*["\'](https?://[^"\']+\.m3u8[^"\']*)',
        r'(https?://[^"\']+\.m3u8[^"\']*)',
        r'file["\']\s*:\s*["\'](https?://[^"\']+\.mp4[^"\']*)',
        r'content=["\'](https?://[^"\']+\.mp4[^"\']*)',
        r'content=["\'](https?://[^"\']+)["\']\s+property=["\']og:video:url["\']',
        r'property=["\']og:video:url["\']\s+content=["\'](https?://[^"\']+)["\']'
    ]
    
    for pattern in patterns:
        match = re.search(pattern, html, re.IGNORECASE)
        if match:
            res = match.group(1).replace('\\/', '/')
            xbmc.log(f"SivaDelight Resolved SUCCESS: {res[:50]}...", xbmc.LOGINFO)
            if '.php' in res and 'url=' in res:
                # Handle cases like /player/load_vtt.php?url=...
                pass 
            
            if '|' not in res:
                res += headers_str
            return res

    # 4b. Try Unpack if direct patterns failed
    unpacked = unpack_eval(html)
    if unpacked:
        for pattern in patterns:
            match = re.search(pattern, unpacked, re.IGNORECASE)
            if match:
                res = match.group(1).replace('\\/', '/')
                if '|' not in res:
                    res += headers_str
                return res
            
    # 5. Recursive iframe (limit 2 deep)
    # To prevent freezing, we only check the FIRST matching iframe and limit recursion
    if depth > 1: return url

    soup = BeautifulSoup(html, "html.parser")
    iframes = soup.find_all('iframe')
    for iframe in iframes:
        src = iframe.get('src') or iframe.get('data-src') or iframe.get('data-lazy-src')
        if src:
            if src.startswith('//'):
                src = 'https:' + src
            if any(x in src for x in ['playall', 'video', 'embed', 'uqload', 'stream', 'dood', 'voe', 'mixdrop', 'cloudbulb', 'cdnbulb', 'tamilgun', 'bysera', 'goembed', 'beer', '0gomovies', 'player4me']):
                # Prevent infinite loops and deep hangs
                if src != url:
                    xbmc.log(f"SivaDelight Following iframe: {src}", xbmc.LOGINFO)
                    # We only follow the FIRST promising iframe to avoid N*N request explosion
                    return resolve_url(src, referer=url, depth=depth + 1)
            
    return url
