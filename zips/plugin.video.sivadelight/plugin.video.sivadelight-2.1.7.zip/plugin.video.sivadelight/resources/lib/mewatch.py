import requests
import json
import xbmc

class MeWatchProvider:
    BASE_URL = "https://cdn.mewatch.sg/api"
    
    def __init__(self):
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
            "Referer": "https://www.mewatch.sg/",
            "Origin": "https://www.mewatch.sg"
        }

    def get_categories(self):
        """Fetches the main Tamil page structure and extracts list categories."""
        # Page ID for /languages/tamil is 137911
        url = f"{self.BASE_URL}/page?path=/languages/tamil"
        try:
            response = requests.get(url, headers=self.headers, timeout=10)
            if response.status_code == 200:
                data = response.json()
                categories = []
                for entry in data.get("entries", []):
                    if entry.get("type") == "ListEntry" and entry.get("title"):
                        categories.append({
                            "title": entry["title"],
                            "id": entry["id"]
                        })
                return categories
        except Exception as e:
            xbmc.log(f"[SivaDelight] meWATCH Error: {str(e)}", xbmc.LOGERROR)
        return []

    def get_list_items(self, list_id):
        """Fetches items for a specific list ID."""
        url = f"{self.BASE_URL}/lists?ids={list_id}&lang=en&ff=idp,ldp,rpt,cd&segments=all"
        try:
            response = requests.get(url, headers=self.headers, timeout=10)
            if response.status_code == 200:
                data = response.json()
                items = []
                for list_data in data:
                    items_list = list_data.get("items", [])
                    for entry in items_list:
                        items.append({
                            "title": entry["title"],
                            "id": entry["id"],
                            "image": entry.get("images", {}).get("standard"),
                            "type": entry.get("type", "movie") # movie, series, show, season, etc.
                        })
                return items
        except Exception as e:
            xbmc.log(f"[SivaDelight] meWATCH List Error: {str(e)}", xbmc.LOGERROR)
        return []

    def get_item_children(self, item_id):
        """Fetches seasons for a show or episodes for a season."""
        url = f"{self.BASE_URL}/items/{item_id}/children?ff=idp,ldp,rpt,cd&lang=en&segments=all"
        try:
            response = requests.get(url, headers=self.headers, timeout=10)
            if response.status_code == 200:
                data = response.json()
                items = []
                # Children API returns a list of items directly or in an object
                if isinstance(data, dict):
                    entries = data.get("items", [])
                else:
                    entries = data
                
                for entry in entries:
                    items.append({
                        "title": entry["title"],
                        "id": entry["id"],
                        "image": entry.get("images", {}).get("standard"),
                        "type": entry.get("type", "episode")
                    })
                return items
        except Exception as e:
            xbmc.log(f"[SivaDelight] meWATCH Children Error: {str(e)}", xbmc.LOGERROR)
        return []

    def get_stream_url(self, item_id):
        """Resolves the HLS manifest URL for an item."""
        # Using the full parameter set discovered in research for better reliability
        url = f"{self.BASE_URL}/items/{item_id}/videos?delivery=stream,progressive&ff=idp,ldp,rpt,cd&lang=en&resolution=External&segments=all"
        try:
            response = requests.get(url, headers=self.headers, timeout=10)
            if response.status_code == 200:
                data = response.json()
                for video in data:
                    if video.get("type") == "hls":
                        return video.get("url")
        except Exception as e:
            xbmc.log(f"[SivaDelight] meWATCH Error: {str(e)}", xbmc.LOGERROR)
        return None

    def get_vasantham_live(self):
        """Specific helper for Vasantham Live (ID: 97096)."""
        return self.get_stream_url("97096")
