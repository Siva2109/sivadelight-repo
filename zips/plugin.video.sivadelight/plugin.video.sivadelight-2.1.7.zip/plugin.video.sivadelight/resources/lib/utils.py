import requests

def get_html(url, headers=None, referer=None, verify=False):
    # Use a more comprehensive set of headers to bypass bot checks
    base_headers = {
        'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_8 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.2 Mobile/15E148 Safari/604.1',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
    
    if headers:
        base_headers.update(headers)
    if referer:
        base_headers['Referer'] = referer
    
    try:
        # Bypassing SSL verification to assist with Android failures
        requests.packages.urllib3.disable_warnings() 
        
        # Use a Session for cookie handling and persistence
        session = requests.Session()
        session.headers.update(base_headers)
        
        response = session.get(url, verify=verify, timeout=30)
        response.raise_for_status()
        return response.text
    except Exception as e:
        try:
            import xbmc
            xbmc.log(f"SivaDelight utils error fetching {url}: {e}", xbmc.LOGERROR)
        except ImportError:
            print(f"SivaDelight utils error fetching {url}: {e}")
        return ""
