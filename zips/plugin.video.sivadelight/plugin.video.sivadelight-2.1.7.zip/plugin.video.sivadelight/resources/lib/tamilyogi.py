import re
from bs4 import BeautifulSoup
from resources.lib.utils import get_html

BASE_URL = "https://tamilyogi.cx"

def get_menus():
    html = get_html(BASE_URL, verify=False)
    soup = BeautifulSoup(html, "html.parser")
    menus = []
    
    nav = soup.find('ul', class_='nav')
    if nav:
        links = nav.find_all('a')
        for link in links:
            href = link.get('href')
            title = link.text.strip()
            if href and title and title.lower() != 'home':
                if href.startswith('/'):
                    href = BASE_URL + href
                if href not in [m['url'] for m in menus]:
                    menus.append({'title': title, 'url': href})
                    
    if not menus:
        # Fallback
        menus.append({'title': 'New Tamil Movies', 'url': f'{BASE_URL}/movie?language=tamil'})
        menus.append({'title': 'Tamil Dubbed Movies', 'url': f'{BASE_URL}/movie?language=tamil-dubbed'})
        menus.append({'title': 'Top IMDB', 'url': f'{BASE_URL}/top-imdb'})
        
    return menus

def get_movies(category_url):
    html = get_html(category_url, verify=False)
    soup = BeautifulSoup(html, "html.parser")
    movies = []
    
    # New Tamilyogi grid layout
    posts = soup.find_all('div', class_='flw-item')
    if not posts:
        # Fallback to old layout
        posts = soup.find_all('div', id=re.compile(r'post-\d+'))

    for post in posts:
        title_tag = post.find('h3', class_='film-name') or post.find('h2')
        if not title_tag:
            continue
            
        a_tag = title_tag.find('a')
        if not a_tag:
            continue
            
        url = a_tag.get('href')
        if url and url.startswith('/'):
            url = BASE_URL + url
            
        title = a_tag.text.strip()
        
        img_url = ""
        img_tag = post.find('img', class_='film-poster-img') or post.find('img')
        if img_tag:
            img_url = img_tag.get('src') or img_tag.get('data-src')
            if img_url and img_url.startswith('//'):
                img_url = 'https:' + img_url
            elif img_url and img_url.startswith('/'):
                img_url = BASE_URL + img_url
                
        if url and title:
            movies.append({
                'title': title,
                'url': url,
                'image': img_url
            })
            
    next_page = None
    next_tag = soup.find('a', class_='next page-numbers') # Or whatever they use
    if not next_tag:
        # Tamilyogi uses specific classes / IDs for pagination usually
        next_tag = soup.find('a', text=re.compile(r'(?i)next'))
    if next_tag and next_tag.get('href'):
        next_page = next_tag.get('href')
        
    return movies, next_page

def get_players(movie_url):
    html = get_html(movie_url, verify=False)
    soup = BeautifulSoup(html, "html.parser")
    players = []
    seen_urls = set()
    
    # Typically Tamilyogi embeds the iframe directly on the movie page
    iframes = soup.find_all('iframe')
    for i, iframe in enumerate(iframes):
        src = iframe.get('src') or iframe.get('data-src')
        if src and ('youtube' not in src) and src not in seen_urls:
            if src.startswith('//'):
                src = 'https:' + src
            players.append({
                'title': f'Player {i+1}',
                'url': src,
                'is_iframe': True
            })
            seen_urls.add(src)
            
    # Look for links as well
    links = soup.find_all('a')
    for link in links:
        href = link.get('href')
        text = link.text.strip().lower()
        if href and ('watch' in text or 'player' in text or 'server' in text or 'watch-movie' in href) and href not in seen_urls:
            # Clean up URL
            if href.startswith('//'):
                href = 'https:' + href
            elif href.startswith('/'):
                href = BASE_URL + href
                
            # Exclude self links but include watch pages
            if (BASE_URL not in href or 'watch-movie' in href) and href != movie_url:
                players.append({
                    'title': link.text.strip() or "Watch Online",
                    'url': href,
                    'is_iframe': False
                })
                seen_urls.add(href)
                
    return players
