import re
from . import utils
from bs4 import BeautifulSoup

BASE_URL = 'https://tamilbulb.cc'

def get_menus():
    return [
        {'title': 'New Movies', 'url': f'{BASE_URL}/video-category/new1movies/'},
        {'title': 'HD Movies', 'url': f'{BASE_URL}/video-category/movies/'},
        {'title': 'Dubbed Movies', 'url': f'{BASE_URL}/video-category/dmovie/'}
    ]

def get_movies(url):
    html = utils.get_html(url)
    if not html:
        return [], None
    
    soup = BeautifulSoup(html, 'html.parser')
    movies = []
    seen_urls = set()
    
    # The site uses Vidmov theme. Items are usually in article or div with class post/video-item
    items = soup.select('article, div.post, div.video-item')
    
    for item in items:
        link_tag = item.find('a', href=re.compile(r'/Movie/'))
        if not link_tag:
            continue
            
        movie_url = link_tag.get('href')
        if movie_url in seen_urls:
            continue
            
        title_tag = item.find(['h2', 'h3'])
        title = title_tag.get_text(strip=True) if title_tag else link_tag.get('title', 'Unknown Movie')
        
        if not title or title.lower() in ['new movie', 'hd movie', 'dubbed movie']:
            # Sometimes titles are inside a specific class
            title_tag = item.select_one('.entry-title, .video-title')
            if title_tag:
                title = title_tag.get_text(strip=True)
        
        img_tag = item.find('img')
        image = ''
        if img_tag:
            # Check for multiple possible image attributes (Vidmov theme often uses lazy loading)
            image = img_tag.get('data-src') or img_tag.get('data-lazy-src') or img_tag.get('src') or ''
            
            # If it's still a placeholder or empty, try a more aggressive search in the item
            if not image or 'placeholder' in image:
                # Some themes use background-image in a div
                style = item.get('style', '')
                match = re.search(r'url\((["\']?)([^)]+)\1\)', style)
                if match:
                    image = match.group(2)
        
        if image and image.startswith('//'):
            image = 'https:' + image

        movies.append({
            'title': title,
            'url': movie_url,
            'image': image
        })
        seen_urls.add(movie_url)

    # Next page
    next_page = None
    next_tag = soup.find('a', class_='next')
    if not next_tag:
        next_tag = soup.find('a', string=re.compile(r'Next|»'))
    if next_tag:
        next_page = next_tag.get('href')
    
    return movies, next_page

def get_players(url):
    html = utils.get_html(url)
    if not html:
        return []
        
    players = []
    
    # TamilBulb uses beeteam368 WordPress plugin. Players are NOT in the DOM as rendered iframes;
    # they are embedded as JSON arguments to beeteam368_pro_player() calls inside <script> tags.
    # BS4 fails to parse these scripts correctly so we use raw regex on the HTML string.
    #
    # Pattern:
    #   jQuery('#beeteam368_player_XXXXX').beeteam368_pro_player({"video_url":"<iframe src=\"...\">", ...})
    #
    # The video_url contains an escaped iframe: \/\/ for //, \" for "

    # Step 1: Get labels from vidmov_jav_js_object if available
    # Pattern: vidmov_jav_js_object['beeteam368_player_XXXX'] = {...}
    labels = {}
    for m in re.finditer(r"vidmov_jav_js_object\['(beeteam368_player_[^']+)'\]\s*=\s*\{([^;]+)\};", html):
        player_id = m.group(1)
        obj_content = m.group(2)
        label_m = re.search(r'"server_label"\s*:\s*"([^"]+)"', obj_content)
        if label_m:
            labels[player_id] = label_m.group(1)
    
    # Step 2: Extract each player video URL from the beeteam368_pro_player() calls
    # Use a simpler approach: find each video_url field in the raw HTML
    for m in re.finditer(
        r"jQuery\('#(beeteam368_player_[^']+)'\)\.beeteam368_pro_player\(\{([^;]+?)\}\);",
        html, re.DOTALL
    ):
        player_id = m.group(1)
        json_content = m.group(2)
        
        # Extract the video_url value - it's a JSON string field
        # The iframe URL is escaped inside: src=\\\"URL\\\"
        url_m = re.search(r'"video_url"\s*:\s*"(.*?)"(?:,|\s*\})', json_content, re.DOTALL)
        if not url_m:
            continue
        
        video_url_str = url_m.group(1)
        
        # The string contains escaped slash (\/) and escaped quote (\") from JSON encoding
        video_url_str = video_url_str.replace('\\/', '/').replace('\\"', '"')
        
        # Now extract the iframe src
        src_m = re.search(r'src=["\']([^"\']+)["\']', video_url_str)
        if not src_m:
            continue
        
        iframe_src = src_m.group(1)
        
        # Check if the iframe is the streambulb wrapper which hides multiple players
        if 'streambulb.site/index.php?id=' in iframe_src:
            # Transform to the actual tamilbulb embed page that has the 5 players
            video_id = iframe_src.split('id=')[-1].split('&')[0]
            embed_url = f"{BASE_URL}/embed/index.php?id={video_id}"
            
            # Fetch the wrapper page
            embed_html = utils.get_html(embed_url, referer=url)
            if embed_html:
                embed_soup = BeautifulSoup(embed_html, 'html.parser')
                player_items = embed_soup.select('.player-item')
                
                # If we found the multi-player list, add all of them
                if player_items:
                    for item in player_items:
                        name_tag = item.select_one('.player-name')
                        name = name_tag.get_text(strip=True) if name_tag else "Unknown Player"
                        
                        iframe_tag = item.find('iframe')
                        if iframe_tag and iframe_tag.get('src'):
                            src = iframe_tag.get('src')
                            # Ensure schema is present
                            if src.startswith('//'):
                                src = 'https:' + src
                            players.append({
                                'title': name,
                                'url': src
                            })
                    continue  # Skip adding the wrapper itself
        
        # If it wasn't the multi-player wrapper or we couldn't parse it, add it as a single player
        label = labels.get(player_id, f'Player {len(players) + 1}')
        players.append({
            'title': label,
            'url': iframe_src
        })
    
    # Fallback: look for any video embed iframes in raw HTML
    if not players:
        for src in re.findall(r'<iframe[^>]+src=["\']([^"\']+)["\']', html, re.IGNORECASE):
            if any(p in src for p in ['streambulb', 'cdnbulb', 'cloudbulb', 'tamilgun', 'byseraguci']):
                players.append({'title': 'Video Player', 'url': src})
                
    return players
