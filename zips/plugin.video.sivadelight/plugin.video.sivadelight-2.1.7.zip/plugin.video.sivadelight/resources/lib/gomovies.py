import re
from bs4 import BeautifulSoup
from resources.lib.utils import get_html
import urllib.parse
import xbmcgui
import xbmc

BASE_URL = "https://ww10.0gomovies.com.pk"

def get_menus():
    return [
        {'title': 'Tamil Movies', 'url': f'{BASE_URL}/genre/tamil-movies-0go/'},
        {'title': 'Movies', 'url': f'{BASE_URL}/movie/'},
        {'title': 'Telugu Movies', 'url': f'{BASE_URL}/genre/telugu/'},
        {'title': 'Malayalam Movies', 'url': f'{BASE_URL}/genre/gomovies-malayalam/'},
        {'title': 'Kannada Movies', 'url': f'{BASE_URL}/genre/kannada/'},
        {'title': 'Hindi Movies', 'url': f'{BASE_URL}/genre/hindi-movies-0go/'},
        {'title': 'Hindi Dubbed', 'url': f'{BASE_URL}/genre/hindi-dubbed/'},
        {'title': 'Web Series', 'url': f'{BASE_URL}/genre/hindi-web-series/'},
    ]

def get_movies(url):
    html = get_html(url, verify=False)
    if not html:
        return [], None
        
    soup = BeautifulSoup(html, "html.parser")
    movies = []
    
    # New selector: a.ml-mask.jt
    items = soup.find_all('a', class_=re.compile(r'ml-mask'))
    for item in items:
        title = item.find('h2')
        if title:
            title = title.text.strip()
        else:
            title = item.get('title') or ""
            
        iurl = item.get('href')
        img_tag = item.find('img')
        thumb = ""
        if img_tag:
            thumb = img_tag.get('data-original') or img_tag.get('src') or ""
            
        if iurl and title:
            movies.append({
                'title': title,
                'url': iurl,
                'image': thumb
            })
            
    next_page = None
    pagination = soup.find('div', id='pagination')
    if pagination:
        active = pagination.find('span', class_='active')
        if active:
            # Look for the next element or a tag after active
            next_tag = pagination.find('a', class_='next') or pagination.find('a', text=re.compile(r'(?i)next'))
            if not next_tag:
                # Try to find the link after the active span
                links = pagination.find_all('a')
                for i, link in enumerate(links):
                    if link.find_previous('span', class_='active'):
                         next_tag = link
                         break
            
            if next_tag and next_tag.get('href'):
                next_page = next_tag.get('href')
                
    return movies, next_page

def get_players(url):
    try:
        xbmcgui.Dialog().ok('GoMovies Shutdown', 'This site is closing and has high protection. Playback may fail. Please try MovieRulz or TamilGun instead.')
    except:
        pass
    # GoMovies usually has a 'watching' page
    if not url.endswith('watching/'):
        if url.endswith('/'):
            url += 'watching/'
        else:
            url += '/watching/'
            
    html = get_html(url, verify=False)
    if not html:
        return []
        
    soup = BeautifulSoup(html, "html.parser")
    players = []
    
    # SivaDelight logic: look in ul class="dropdown-menu"
    # Also look for <ul class="list-server-items">
    server_list = soup.find('ul', class_='list-server-items')
    if server_list:
        items = server_list.find_all('li', class_='btn-sm')
        for item in items:
            p_url = item.get('data-video')
            p_title = item.text.strip()
            if p_url:
                if p_url.startswith('//'): p_url = 'https:' + p_url
                players.append({
                    'title': p_title or "Mirror",
                    'url': p_url,
                    'is_direct': False
                })

    menu = soup.find('ul', class_='dropdown-menu')
    if menu:
        items = menu.find_all('li')
        for item in items:
            p_url = item.get('data-drive') or item.get('data-openload') or item.get('data-streamgo') or item.get('data-putload')
            p_title = item.text.strip()
            if p_url:
                if p_url.startswith('//'): p_url = 'https:' + p_url
                
                if '/hls/' in p_url:
                    players.append({
                        'title': 'CDN Direct',
                        'url': p_url + '|User-Agent=iPad',
                        'is_direct': True
                    })
                else:
                    players.append({
                        'title': p_title or "Video Player",
                        'url': p_url,
                        'is_direct': False
                    })
                    
    # Look for the big Blue buttons "Server 1", "Server 2" etc
    btns = soup.find_all('a', class_='btn-player')
    for btn in btns:
        href = btn.get('href')
        if href and 'javascript' not in href:
            players.append({'title': btn.text.strip(), 'url': href, 'is_direct': False})

    # Fallback to iframes
    iframes = soup.find_all('iframe')
    for i, iframe in enumerate(iframes):
        src = iframe.get('src') or iframe.get('data-src') or iframe.get('data-lazy-src')
        if src:
            if src.startswith('//'): src = 'https:' + src
            if 'youtube' in src: continue
            # Avoid duplicates
            if not any(p['url'] == src for p in players):
                players.append({
                    'title': f'Player {len(players)+1}',
                    'url': src,
                    'is_direct': False
                })
                
    return players
