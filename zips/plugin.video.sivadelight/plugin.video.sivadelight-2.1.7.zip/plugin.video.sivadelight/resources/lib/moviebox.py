"""
MovieBox scraper for plugin.video.sivadelight
Site: https://moviebox.ph
Uses the h5-api.aoneroom.com REST API for movie listings and stream resolution.
"""
import re
import json
from resources.lib.utils import get_html

BASE_URL = "https://moviebox.ph"
API_BASE = "https://h5.aoneroom.com"

# API headers required for aoneroom API
API_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
    'Accept': 'application/json',
    'Origin': 'https://moviebox.ph',
    'Referer': 'https://moviebox.ph/',
}

def _api_get(path, params=None):
    """Helper: call the MovieBox API and return parsed JSON."""
    import xbmc
    try:
        from resources.lib.utils import requests
        url = API_BASE + path
        
        # Use a more modern and consistent set of headers
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
            'Accept': 'application/json, text/plain, */*',
            'Origin': 'https://moviebox.ph',
            'Referer': 'https://moviebox.ph/',
            'Accept-Language': 'en-US,en;q=0.9',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-site',
        }
        
        r = requests.get(url, headers=headers, params=params, verify=False, timeout=15)
        xbmc.log(f"MovieBox API call {path} status: {r.status_code}", xbmc.LOGINFO)
        
        if r.status_code == 200:
            return r.json()
    except Exception as e:
        xbmc.log(f"MovieBox API error {path}: {str(e)}", xbmc.LOGERROR)
    return None

def get_menus():
    return [
        {'name': 'Tamil Movies', 'url': 'tamil'},
        {'name': 'Telugu Movies', 'url': 'telugu'},
        {'name': 'Hindi Movies', 'url': 'hindi'},
        {'name': 'Latest Movies', 'url': 'latest'},
        {'name': 'Top Rated', 'url': 'top_rated'},
        {'name': 'Action Movies', 'url': 'action'},
        {'name': 'Comedy Movies', 'url': 'comedy'},
        {'name': 'Drama Movies', 'url': 'drama'},
    ]

def get_movies(category, page=1):
    """
    Returns list of dicts: {name, url, thumbnail}
    """
    import xbmc
    movies = []

    # Map categories to search parameters
    genre_map = {
        'tamil': {'language': 'Tamil'},
        'telugu': {'language': 'Telugu'},
        'hindi': {'language': 'Hindi'},
        'action': {'genre': 'Action'},
        'comedy': {'genre': 'Comedy'},
        'drama': {'genre': 'Drama'},
    }

    try:
        params = {
            'page': page,
            'size': 24,
            'subjectType': 1,  # 1 = Movie
        }
        
        if category in genre_map:
            params.update(genre_map[category])
        elif category == 'latest':
            params['orderBy'] = 'releaseDate'
        elif category == 'top_rated':
            params['orderBy'] = 'imdbRating'

        # Try search API first
        data = _api_get('/v2/subject/search', params)
        if data and data.get('data'):
            items = data['data']
            if isinstance(items, list):
                for item in items:
                    subject_id = item.get('id') or item.get('subjectId')
                    title = item.get('title') or item.get('postTitle') or item.get('name', '')
                    thumb = item.get('poster') or item.get('cover', {}).get('url', '')
                    
                    movie_url = f"{BASE_URL}/web/detail/{subject_id}" if subject_id else ''
                    if title and subject_id:
                        movies.append({'name': title, 'url': movie_url, 'thumbnail': thumb, 'id': str(subject_id)})
        
        xbmc.log(f"MovieBox got {len(movies)} movies for category '{category}'", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"MovieBox get_movies error: {str(e)}", xbmc.LOGERROR)
    
    return movies

def get_players(url):
    """
    Returns list of player dicts: {name, url}
    """
    import xbmc
    players = []
    
    try:
        xbmc.log(f"MovieBox fetching players for: {url}", xbmc.LOGINFO)
        id_match = re.search(r'/detail/([^/?]+)', url)
        if not id_match:
            return []
        
        subject_id = id_match.group(1)
        
        # Use verified resource endpoint
        data = _api_get('/v2/resource/get', {'id': subject_id, 'subjectType': 1})
        if data and data.get('data'):
            res_data = data['data']
            res_list = res_data.get('resourceList', [])
            for res in res_list:
                stream_url = res.get('url')
                quality = res.get('quality', 'Standard')
                if stream_url:
                    players.append({'name': quality, 'url': stream_url})
        
        # Fallback to detail page if no direct streams found
        if not players:
            players.append({'name': 'MovieBox Primary', 'url': url})
            
    except Exception as e:
        xbmc.log(f"MovieBox get_players error: {str(e)}", xbmc.LOGERROR)
    
    return players
