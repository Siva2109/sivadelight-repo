import re
from bs4 import BeautifulSoup
from resources.lib.utils import get_html
import xbmc

BASE_URL = "https://www.tamilbliss.ru"

def get_menus():
    return [
        {'title': 'Vijay TV Serial', 'url': f'{BASE_URL}/category/vijay-tv-serial/', 'id': 'vijay-tv'},
        {'title': 'Vijay TV Shows', 'url': f'{BASE_URL}/category/vijay-tv-shows/', 'id': 'vijay-tv'},
        {'title': 'Sun TV Serial', 'url': f'{BASE_URL}/category/sun-tv-serial/', 'id': 'sun-tv'},
        {'title': 'Sun TV Shows', 'url': f'{BASE_URL}/category/sun-tv-shows/', 'id': 'sun-tv'},
        {'title': 'Zee Tamil Serial', 'url': f'{BASE_URL}/category/zee-tamil-serial/', 'id': 'zee-tamil'},
        {'title': 'Zee Tamil Shows', 'url': f'{BASE_URL}/category/zee-tamil-tv-shows/', 'id': 'zee-tamil'}
    ]

def get_episodes(url):
    html = get_html(url, verify=False)
    soup = BeautifulSoup(html, "html.parser")
    episodes = []
    
    # Try multiple common patterns for TD Newspaper and generic themes
    items = soup.find_all('article') or soup.find_all('div', class_=re.compile(r'post|module|unit'))
    
    if not items:
        # If no wrappers found, try to find links directly and then find their containers
        links = soup.find_all('a', rel='bookmark')
        items = [link.find_parent(['div', 'article']) for link in links if link.find_parent(['div', 'article'])]

    for item in items:
        # Title and Link - be very aggressive finding the link
        a_tag = item.find('a', rel='bookmark') or item.find('a', title=True)
        if not a_tag:
            # Look for any link with a title-like string or inside a header
            header = item.find(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])
            if header:
                a_tag = header.find('a')
        
        if not a_tag:
            continue
            
        title = a_tag.get('title') or a_tag.text.strip()
        iurl = a_tag.get('href')
        
        # Avoid duplicate navigation or next/prev links
        if not iurl or 'category' in iurl or 'page/' in iurl:
            continue
        
        # Thumbnail
        thumb = ""
        img_tag = item.find('img')
        if img_tag:
            thumb = img_tag.get('src')
            # Handle lazy loading
            if thumb and (thumb.startswith('data:') or 'pixel' in thumb):
                thumb = img_tag.get('data-src') or img_tag.get('data-lazy-src') or thumb
            if thumb and thumb.startswith('//'):
                thumb = 'https:' + thumb

        if iurl and title:
            episodes.append({
                'title': title,
                'url': iurl,
                'image': thumb
            })

    # Pagination
    next_page = None
    pagination = soup.find('div', class_='page-nav') or soup.find('nav', class_='navigation')
    if pagination:
        next_tag = pagination.find('a', class_='next') or pagination.find('a', string=re.compile(r'Next|>', re.I))
        if next_tag and next_tag.get('href'):
            next_page = next_tag.get('href')

    return episodes, next_page

def get_players(url):
    html = get_html(url, verify=False)
    soup = BeautifulSoup(html, "html.parser")
    players = []
    seen_urls = set()
    
    content = soup.find('div', class_='entry-content') or soup.find('div', class_='post-content')
    if not content:
        return players

    # Look for any links with 'Watch' or 'Player' labels
    all_links = content.find_all('a')
    for a in all_links:
        vurl = a.get('href')
        vtext = a.get_text().strip()
        
        if not vurl: continue
        
        # Priority 1: Direct iframes inside links (sometimes happens)
        # Priority 2: 'Watch Now' or 'Player' labeled links
        if any(k in vtext.lower() for k in ['watch', 'player']) or 'getlink.php' in vurl:
            if vurl not in seen_urls:
                # Clean URL
                if vurl.startswith('//'): vurl = 'https:' + vurl
                if vurl.startswith('/'): vurl = BASE_URL + vurl
                
                label = vtext if vtext else "Player"
                if 'getlink.php' in vurl: label = "Watch Online"
                
                # Attempt to resolve getlink.php to a real iframe if possible
                try:
                    if 'getlink.php' in vurl:
                        # Fetch the landing page to see if it redirects or has an iframe
                        inner_html = get_html(vurl, referer=url, verify=False)
                        inner_soup = BeautifulSoup(inner_html, "html.parser")
                        iframe = inner_soup.find('iframe')
                        if iframe:
                            src = iframe.get('src')
                            if src:
                                vurl = src
                                label = "Video Source"
                except:
                    pass

                players.append({
                    'title': f"{label} {len(players)+1}",
                    'url': vurl,
                    'is_iframe': True if 'iframe' in str(vurl) or 'dailymotion' in vurl or 'youtube' in vurl else False
                })
                seen_urls.add(vurl)

    return players
