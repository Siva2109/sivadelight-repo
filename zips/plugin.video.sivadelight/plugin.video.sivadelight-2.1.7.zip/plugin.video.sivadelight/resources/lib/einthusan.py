import re
import json
import base64
import random
import time
import requests
from bs4 import BeautifulSoup
from resources.lib.utils import get_html

BASE_URL = "https://einthusan.tv"

def b64decode(text):
    return base64.b64decode(text).decode('utf-8', errors='ignore')

def b64encode(text):
    return base64.b64encode(text.encode('utf-8')).decode('utf-8')

def decrypt(e):
    t = 10
    i = e[0:t] + e[-1] + e[t + 2:-1]
    i = b64decode(i)
    return json.loads(i)

def encrypt(t):
    e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
    n = 10
    a = json.dumps(t)
    a = b64encode(a.replace(' ', ''))
    a = a[0:n] + random.choice(e) + random.choice(e) + a[n + 1:] + a[n]
    return a

def get_sort_cdn(slist):
    ejo = []
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }
    for server in slist:
        try:
            params = {'_': int(time.time() * 1000)}
            r = requests.get(server, params=params, headers=headers, timeout=5, verify=False)
            ejo.append((r.elapsed.total_seconds(), server))
        except:
            ejo.append((99, server))
    
    ejo_sorted = [x for _, x in sorted(ejo)]
    return encrypt(ejo_sorted)

def get_menus():
    return [
        {'title': 'Tamil', 'url': f'{BASE_URL}/launcher/?lang=tamil'},
        {'title': 'Telugu', 'url': f'{BASE_URL}/launcher/?lang=telugu'},
        {'title': 'Malayalam', 'url': f'{BASE_URL}/launcher/?lang=malayalam'},
        {'title': 'Kannada', 'url': f'{BASE_URL}/launcher/?lang=kannada'},
        {'title': 'Hindi', 'url': f'{BASE_URL}/launcher/?lang=hindi'},
        {'title': 'Bengali', 'url': f'{BASE_URL}/launcher/?lang=bengali'},
        {'title': 'Marathi', 'url': f'{BASE_URL}/launcher/?lang=marathi'},
        {'title': 'Punjabi', 'url': f'{BASE_URL}/launcher/?lang=punjabi'},
    ]

def get_categories(url):
    html = get_html(url)
    if not html:
        return []
        
    soup = BeautifulSoup(html, "html.parser")
    cats = []
    
    lang = url.split('=')[1] if '=' in url else 'tamil'
    thumb = f'http://s3.amazonaws.com/einthusanthunderbolt/etc/img/{lang}.jpg'
    
    # Navigation items
    nav = soup.find('section', id='UILaunchPad')
    if nav:
        items = nav.find_all('li')
        for item in items:
            if 'data-disabled' in item.attrs: continue
            a_tag = item.find('a')
            p_tag = item.find('p')
            if a_tag and p_tag:
                title = p_tag.text.strip()
                if title not in ['Feed', 'Contact', 'Go Premium']:
                    link = BASE_URL + a_tag.get('href')
                    cats.append({'title': title, 'url': link, 'image': thumb})
                    
    # Hardcoded sorted categories
    list2 = {'Recent': 'Recently Added', 'StaffPick': 'Staff Picks', 'Popularity': 'Most Watched'}
    for key, title in list2.items():
        link = f'{BASE_URL}/movie/results/?lang={lang}&find={key}'
        if key == 'Popularity':
            link += '&ptype=View&tp=l30d'
        cats.append({'title': title, 'url': link, 'image': thumb})
        
    # Search
    search_url = f'{BASE_URL}/movie/results/?lang={lang}&query='
    cats.append({'title': '[COLOR yellow]** Search Movies **[/COLOR]', 'url': search_url, 'image': thumb})
    
    return cats

    html = get_html(url)
    if not html:
        return [], None
        
    if "Service has been halted" in html or "Service Unavailable" in html:
        try:
             import xbmc
             xbmc.log("Einthusan: Service is geo-blocked in your region.", xbmc.LOGWARNING)
        except:
             print("Einthusan: Service is geo-blocked in your region.")
        return [], None
        
    soup = BeautifulSoup(html, "html.parser")
    movies = []
    
    # New structure as identified in audit: li elements with a.title
    items = soup.find_all('li')
    for item in items:
        # Each movie is usually in an li that contains a div with classes for thumbnail and title
        title_a = item.find('a', class_='title')
        if not title_a:
            # Fallback for search or other views
            title_a = item.find('a')
            if not title_a or not title_a.find('h3'):
                continue
                
        title_h3 = title_a.find('h3')
        if not title_h3:
            continue
            
        title = title_h3.text.strip()
        link = title_a.get('href')
        
        # Thumbnail in div.block1 or similar
        thumb = ""
        img_container = item.find('div', class_=re.compile(r'block1|thumbnail'))
        if img_container:
            img = img_container.find('img')
            if img:
                thumb = img.get('src') or ""
        else:
            # Fallback img search in item
            img = item.find('img')
            if img:
                thumb = img.get('src') or ""

        if link and title:
            full_url = BASE_URL + link if link.startswith('/') else BASE_URL + '/' + link
            if thumb and not thumb.startswith('http'):
                thumb = 'https:' + thumb if thumb.startswith('//') else 'https://' + thumb

            movies.append({
                'title': title,
                'url': full_url,
                'image': thumb
            })
            
    next_page = None
    # Pagination in Einthusan: look for a link with 'Next' or specific icon
    paginator = soup.find('a', class_=re.compile(r'next|nav-next'))
    if paginator:
        next_page = BASE_URL + paginator.get('href').replace('&amp;', '&')
    elif not movies:
        # Fallback to regex if logic above found nothing and it's not a block page
        items_regex = re.findall(r'data-disabled="false"\s*href="([^"]+)".+?h3>([^<]+)', html, re.DOTALL)
        for link, title in items_regex:
             movies.append({'title': title.strip(), 'url': BASE_URL + link, 'image': ''})

    return movies, next_page

def get_video(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Referer': BASE_URL,
        'Origin': BASE_URL
    }
    
    try:
        session = requests.Session()
        r = session.get(url, headers=headers, verify=False, timeout=15)
        html = r.text
        cookies = session.cookies.get_dict()
        
        token_match = re.search('data-pageid="([^"]+)', html)
        ej_match = re.search('data-ejpingables="([^"]+)', html)
        
        if not token_match or not ej_match:
            return None
            
        token = token_match.group(1)
        ej_data = decrypt(ej_match.group(1))
        
        # Sort CDNs
        sorted_ej = get_sort_cdn(ej_data)
        
        xj = {"EJOutcomes": sorted_ej, "NativeHLS": False}
        pdata = {
            'xEvent': 'UIVideoPlayer.PingOutcome',
            'xJson': json.dumps(xj).replace(' ', ''),
            'gorilla.csrf.Token': token
        }
        
        ajax_headers = headers.copy()
        ajax_headers.update({'X-Requested-With': 'XMLHttpRequest'})
        
        ajax_url = url.replace('/movie/watch/', '/ajax/movie/watch/').replace('/movie/view/', '/ajax/movie/view/')
        # If it doesn't match the above, try a generic replace
        if '/ajax/' not in ajax_url:
            ajax_url = url.replace('/movie/', '/ajax/movie/')
            
        r2 = session.post(ajax_url, data=pdata, headers=ajax_headers, verify=False, timeout=15)
        
        # Stream link is in Data -> EJLinks -> MP4Link
        data = r2.json()
        ej_links = decrypt(data['Data']['EJLinks'])
        return ej_links.get('MP4Link')
        
    except Exception as e:
        print(f"Einthusan resolve error: {e}")
        return None
