import re
from bs4 import BeautifulSoup
from resources.lib.utils import get_html
import urllib.parse

BASE_URL = "https://arivumani.net"

def get_channels():
    # Returns hardcoded channels per user request
    return [
        {'id': 'sun-tv', 'title': 'Sun TV', 'url': f'{BASE_URL}/categories/sun-tv/', 'icon': 'SunTv.png'},
        {'id': 'vijay-tv', 'title': 'Vijay TV', 'url': f'{BASE_URL}/categories/vijay-tv/', 'icon': 'VijayTv.png'},
        {'id': 'zee-tamil', 'title': 'Zee Tamil', 'url': f'{BASE_URL}/categories/zee-tamil/', 'icon': 'ZeeTv.png'},
        {'id': 'bigg-boss-tamil', 'title': 'Bigg Boss Tamil', 'url': f'{BASE_URL}/categories/bigg-boss-tamil-season-9/', 'icon': 'BiggBoss.png'}
    ]

def get_episodes(category_url):
    html = get_html(category_url, verify=False)
    if not html:
        return [], None
        
    soup = BeautifulSoup(html, "html.parser")
    episodes = []
    
    articles = soup.find_all('article')
    for article in articles:
        # Find item-img div then a tag
        item_img = article.find('div', class_='item-img')
        if not item_img:
            a_tag = article.find('a')
        else:
            a_tag = item_img.find('a')
            
        if not a_tag:
            continue
            
        url = a_tag.get('href')
        if not url:
            continue
            
        if url.startswith('/'):
            url = BASE_URL + url
            
        # Try to find title
        title = ""
        # 1. From title attr of a_tag
        if a_tag.get('title'):
            title = a_tag.get('title').strip()
        
        # 2. From h3 or h2
        if not title:
            h_tag = article.find(['h3', 'h2', 'h1'])
            if h_tag:
                title = h_tag.text.strip()
                
        # 3. Fallback to URL path format
        if not title:
            path = urllib.parse.urlparse(url).path
            parts = [p for p in path.split('/') if p]
            if parts:
                title = parts[-1].replace('-', ' ').title()
                
        # Try to find image
        img_url = ""
        img_tag = a_tag.find('img') or article.find('img')
        if img_tag:
            img_url = img_tag.get('src') or img_tag.get('data-src')
            if img_url and img_url.startswith('//'):
                img_url = 'https:' + img_url
            elif img_url and img_url.startswith('/'):
                img_url = BASE_URL + img_url
                
        episodes.append({
            'title': title,
            'url': url,
            'image': img_url
        })
        
    next_page = None
    # Pagination is typically <nav class="pagination"> -> <a class="next">
    pagination = soup.find('nav', class_='pagination') or soup.find('div', class_='pagination')
    if pagination:
        next_tag = pagination.find('a', class_='next') or pagination.find('a', text=re.compile(r'(?i)next'))
        if next_tag and next_tag.get('href'):
            next_page = next_tag.get('href')
            if next_page.startswith('/'):
                next_page = BASE_URL + next_page
                
    # Fallback to look for link with text Next
    if not next_page:
        next_tag = soup.find('a', text=re.compile(r'(?i)next'))
        if next_tag and next_tag.get('href'):
            next_page = next_tag.get('href')
            if next_page.startswith('/'):
                next_page = BASE_URL + next_page
                
    return episodes, next_page

def get_videos(episode_url):
    html = get_html(episode_url, verify=False)
    if not html:
        return []
        
    soup = BeautifulSoup(html, "html.parser")
    players = []
    seen_urls = set()
    
    iframes = soup.find_all('iframe')
    for i, iframe in enumerate(iframes):
        src = iframe.get('src') or iframe.get('data-src')
        if src and src not in seen_urls:
            # Exclude ad iframes if obvious
            if 'ads.html' in src or 'banner' in src:
                continue
                
            if src.startswith('//'):
                src = 'https:' + src
            
            # Simple title generation
            player_name = f'Player {i+1}'
            if 'playallu' in src:
                player_name = f'PlayAllu ({i+1})'
                
            players.append({
                'title': player_name,
                'url': src,
                'is_iframe': True
            })
            seen_urls.add(src)
            
    # Also look for a tags with specific keywords
    links = soup.find_all('a')
    for link in links:
        href = link.get('href')
        text = link.text.strip().lower()
        if href and ('playallu' in href or 'play' in text or 'server' in text) and href not in seen_urls:
            if 'arivumani.net' in href and href == episode_url:
                continue
                
            if href.startswith('//'):
                href = 'https:' + href
            
            p_title = link.text.strip() or "Watch Online"
            players.append({
                'title': p_title,
                'url': href,
                'is_iframe': False
            })
            seen_urls.add(href)
            
    return players
