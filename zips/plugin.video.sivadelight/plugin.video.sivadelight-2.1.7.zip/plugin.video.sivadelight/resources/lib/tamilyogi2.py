import re
from bs4 import BeautifulSoup
from resources.lib.utils import get_html

BASE_URL = "https://tamilyogi.horse"

def get_menus():
    html = get_html(BASE_URL, verify=False)
    soup = BeautifulSoup(html, "html.parser")
    menus = []
    
    menu_ul = soup.find('ul', id='menu-home')
    if menu_ul:
        links = menu_ul.find_all('a')
        for link in links:
            href = link.get('href')
            title = link.text.strip()
            if href and title and title.lower() != 'home':
                if href.startswith('/'):
                    href = BASE_URL + href
                if href not in [m['url'] for m in menus]:
                    menus.append({'title': title, 'url': href})
    
    if not menus:
        # Fallback from provided source
        menus.append({'title': 'All Movies', 'url': f'{BASE_URL}/movies/'})
        menus.append({'title': 'Tamil Movies', 'url': f'{BASE_URL}/audio/tamil/'})
        menus.append({'title': 'Dubbed Movies', 'url': f'{BASE_URL}/audio/tamil-dubbed/'})
        
    return menus

def get_movies(category_url):
    html = get_html(category_url, verify=False)
    soup = BeautifulSoup(html, "html.parser")
    movies = []
    
    articles = soup.find_all('article', class_='pro-card')
    for article in articles:
        a_tag = article.find('a')
        if not a_tag:
            continue
            
        url = a_tag.get('href')
        if url and url.startswith('/'):
            url = BASE_URL + url
            
        title_tag = article.find('h3', class_='pro-title')
        title = title_tag.text.strip() if title_tag else ""
        if not title:
            title = a_tag.get('title', '').replace('Watch ', '').replace(' Online HD', '').strip()
            
        img_tag = article.find('img')
        img_url = ""
        if img_tag:
            img_url = img_tag.get('src') or img_tag.get('data-src') or img_tag.get('data-lazy-src')
            if img_url and img_url.startswith('//'):
                img_url = 'https:' + img_url
            elif img_url and img_url.startswith('/'):
                img_url = BASE_URL + img_url
                
        if url and title:
            movies.append({
                'title': title,
                'url': url,
                'image': img_url
            })
            
    next_page = None
    next_tag = soup.find('a', class_='next page-numbers')
    if not next_tag:
        next_tag = soup.find('a', text=re.compile(r'(?i)next|→'))
    if next_tag and next_tag.get('href'):
        next_page = next_tag.get('href')
        if next_page.startswith('/'):
            next_page = BASE_URL + next_page
            
    return movies, next_page

def get_players(movie_url):
    html = get_html(movie_url, verify=False)
    soup = BeautifulSoup(html, "html.parser")
    players = []
    seen_urls = set()
    
    # 1. Look for direct iframes
    iframes = soup.find_all('iframe')
    for i, iframe in enumerate(iframes):
        src = iframe.get('src') or iframe.get('data-src')
        if src and ('youtube' not in src) and src not in seen_urls:
            if src.startswith('//'):
                src = 'https:' + src
            players.append({
                'title': f'Player {i+1}',
                'url': src
            })
            seen_urls.add(src)
            
    # 2. Look for Server buttons or links with JS calls
    # switchSrv('url', this) or loadIframe('url')
    js_calls = re.findall(r"(?:switchSrv|loadIframe)\s*\(\s*['\"]([^'\"]+)['\"]", html)
    for i, url in enumerate(js_calls):
        if url and url not in seen_urls:
            if url.startswith('//'):
                url = 'https:' + url
            players.append({
                'title': f'Server {i+1}',
                'url': url
            })
            seen_urls.add(url)

    # 3. Look for data attributes
    for tag in soup.find_all(attrs={"data-url": True}):
        url = tag['data-url']
        if url and url not in seen_urls:
            players.append({'title': 'Server Data', 'url': url})
            seen_urls.add(url)

    return players
