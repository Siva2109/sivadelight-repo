import re
from bs4 import BeautifulSoup
from resources.lib.utils import get_html
import xbmc

BASE_URL = "https://www.tamildhool.tech"

def get_channels():
    # Hardcoded list based on user request
    return [
        {'title': 'Sun TV', 'id': 'sun-tv', 'icon': 'SunTv.jpg'},
        {'title': 'Vijay TV', 'id': 'vijay-tv', 'icon': 'VijayTv.jpg'},
        {'title': 'Zee Tamil', 'id': 'zee-tamil', 'icon': 'Zee_Tamil.jpeg'}
    ]

def get_subcategories(channel_id):
    # Depending on the channel, return Serial, Show, Program
    if channel_id == 'sun-tv':
        return [
            {'title': 'Sun TV Serial', 'url': f'{BASE_URL}/sun-tv/sun-tv-serial/'},
            {'title': 'Sun TV Show', 'url': f'{BASE_URL}/sun-tv/sun-tv-show/'},
            {'title': 'Sun TV Programs', 'url': f'{BASE_URL}/sun-tv-programs/'}
        ]
    elif channel_id == 'vijay-tv':
        return [
            {'title': 'Vijay TV Serial', 'url': f'{BASE_URL}/vijay-tv/vijay-tv-serial/'},
            {'title': 'Vijay TV Show', 'url': f'{BASE_URL}/vijay-tv/vijay-tv-show/'},
            {'title': 'Vijay TV Programs', 'url': f'{BASE_URL}/vijay-tv-programs/'}
        ]
    elif channel_id == 'zee-tamil':
        return [
            {'title': 'Zee Tamil Serial', 'url': f'{BASE_URL}/zee-tamil/zee-tamil-serial/'},
            {'title': 'Zee Tamil Show', 'url': f'{BASE_URL}/zee-tamil/zee-tamil-show/'},
            {'title': 'Zee Tamil Programs', 'url': f'{BASE_URL}/zee-tamil-programs/'}
        ]
    return []

def get_items(url):
    html = get_html(url, verify=False)
    soup = BeautifulSoup(html, "html.parser")
    episodes = []
    
    main_section = soup.find('main', id='main')
    if not main_section:
        return episodes, None
        
    articles = main_section.find_all('article')
    
    # Handle the "Live" highlight edge case from SivaDelight observations
    if len(articles) == 1:
        marks = main_section.find_all('mark')
        filtered_marks = [m for m in marks if 'live' not in m.text.lower()]
        if filtered_marks and filtered_marks[0].find('a'):
            new_url = filtered_marks[0].find('a').get('href')
            html = get_html(new_url, verify=False)
            soup = BeautifulSoup(html, "html.parser")
            main_section = soup.find('main', id='main')
            if main_section:
                articles = main_section.find_all('article')

    for item in articles:
        # Get Title
        title_tag = item.find('h3') or item.find('h5')
        if title_tag:
            title = title_tag.text.strip()
        else:
            a_tag = item.find('a')
            title = a_tag.get('title', 'Unknown Title').strip() if a_tag else 'Unknown Title'

        # Get URL
        link_parent = item.find('h3') or item
        a_tag = link_parent.find('a')
        if not a_tag:
            continue
        iurl = a_tag.get('href')
        
        # Get Thumb
        thumb = ""
        img_tag = item.find('img')
        if img_tag:
            thumb = img_tag.get('src')
            if thumb and thumb.startswith('data:'):
                thumb = img_tag.get('data-lazy-src', '')
            if thumb and thumb.startswith('//'):
                thumb = 'https:' + thumb

        if iurl and title:
            episodes.append({
                'title': title,
                'url': iurl,
                'image': thumb
            })

    next_page = None
    nav = soup.find('div', class_='navigation') or soup.find('nav', class_='navigation')
    if nav:
        next_tag = nav.find('a', class_='next')
        if next_tag and next_tag.get('href'):
            next_page = next_tag.get('href')
            
    return episodes, next_page

def get_videos(url):
    html = get_html(url, verify=False)
    soup = BeautifulSoup(html, "html.parser")
    players = []
    seen_urls = set()
    
    entry_content = soup.find('div', class_='entry-content')
    if not entry_content:
        return players

    # Remove noscript tags to prevent false positives
    for noscript in entry_content.find_all('noscript'):
        noscript.decompose()

    # 1. Look for <link href="..."> which tamildhool sometimes uses for embeds
    links = entry_content.find_all('link')
    for link in links:
        vidurl = link.get('href')
        if vidurl and vidurl not in seen_urls:
            players.append({
                'title': f"Player {len(players)+1} (Direct)",
                'url': vidurl,
                'is_iframe': True
            })
            seen_urls.add(vidurl)

    # 2. Look for explicit iframes inside figures or content
    iframes = entry_content.find_all('iframe')
    for iframe in iframes:
        src = iframe.get('src')
        if src and src not in seen_urls:
            players.append({
                'title': f"Player {len(players)+1}",
                'url': src,
                'is_iframe': True
            })
            seen_urls.add(src)

    # 3. Look for explicit links inside figures (like tamilbliss)
    figures = entry_content.find_all('figure')
    for figure in figures:
        a_tag = figure.find('a')
        if a_tag:
            vidurl = a_tag.get('href')
            if vidurl and 'tamilbliss.' in vidurl and vidurl not in seen_urls:
                # Based on SivaDelight logic, Tamilbliss links need to be fetched 
                # to extract the actual iframe. For this scraper, we will pass the tamilbliss
                # URL as the player, and let our resolver or the user click it.
                # If we want to resolve it here:
                try:
                    tb_html = get_html(vidurl, referer=url, verify=False)
                    tb_soup = BeautifulSoup(tb_html, "html.parser")
                    inner_a = tb_soup.find('a')
                    if inner_a:
                        tb_inner = inner_a.get('href')
                        tb2_html = get_html(tb_inner, referer=vidurl, verify=False)
                        tb2_soup = BeautifulSoup(tb2_html, "html.parser")
                        tb_iframe = tb2_soup.find('iframe')
                        if tb_iframe:
                            inner_src = tb_iframe.get('src')
                            if inner_src and inner_src not in seen_urls:
                                # Add the referer to the URL so resolvers can handle it
                                players.append({
                                    'title': f"Tamilbliss Player",
                                    'url': f"{inner_src}|Referer={tb_inner}",
                                    'is_iframe': True
                                })
                                seen_urls.add(inner_src)
                except Exception as e:
                    xbmc.log(f"SivaDelight: Failed to parse Tamilbliss link {vidurl} - {str(e)}", xbmc.LOGERROR)

    return players
