from bs4 import BeautifulSoup

with open("showdetails_real_v2.html", "r") as f:
    soup = BeautifulSoup(f.read(), "html.parser")

print("--- VIDEO PLAYER CONTENT ---")
vp = soup.find(class_='video-player')
if vp:
    print(vp.prettify())
else:
    print("video-player not found")

print("\n--- IFRAME CONTAINER CONTENT ---")
ic = soup.find(class_='iframe-container')
if ic:
    print(ic.prettify())
else:
    print("iframe-container not found")

print("\n--- ALL IFRAMES ---")
for iframe in soup.find_all('iframe'):
     print(f"iframe src: {iframe.get('src')}")
